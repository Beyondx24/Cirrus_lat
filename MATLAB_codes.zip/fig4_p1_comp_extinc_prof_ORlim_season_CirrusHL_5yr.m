%% this routine is to plot the comparison of profiles of extinction in years of 2014 and 2018-2021
%% tested under the MATLAB 2010B
clear all; clc; format long; close all
directoryname = pwd;  %% the current folder, where the MATLAB data are stored
%%
fileext    = '_DN_Europe.mat'
% fileext    = '_ZD_Europe.mat';
%% to load the data of FIRST month of season
mm = '03';          % to change the number (03, 06, 09, 12) for different season 
mm_str = 'MAM';     % to change the season (MAM, JJA, SON, DJF)
%% to load data of year 2014
yyyy = '2014';
    filename = ['DPOL_extinc_' yyyy '-' mm fileext];
        load([directoryname '\' filename]);
    dpr2014  = DPOL.dp_ratio;
    temp2014 = DPOL.temperature;
    lat2014  = [DPOL.latitude];
    lon2014  = [DPOL.longitude];
    extinc2014  = DPOL.extinc;
%% to load data of year 2018
yyyy = '2018';
if str2num(mm) > 10
    dpr2018  = [];
    temp2018 = [];
    lat2018  = [];
    lon2018  = [];
    extinc2018  = [];
else
    filename = ['DPOL_extinc_' yyyy '-' mm fileext];
        load([directoryname '\' filename]);
    dpr2018  = DPOL.dp_ratio;
    temp2018 = DPOL.temperature;
    lat2018  = [DPOL.latitude];
    lon2018  = [DPOL.longitude];
    extinc2018  = DPOL.extinc;
end
%% to load data of year 2019
yyyy = '2019';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2019  = DPOL.dp_ratio;
temp2019 = DPOL.temperature;
lat2019  = [DPOL.latitude];
lon2019  = [DPOL.longitude];
extinc2019  = DPOL.extinc;
%% to load data of year 2020
yyyy = '2020';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2020  = DPOL.dp_ratio;
temp2020 = DPOL.temperature;
lat2020  = [DPOL.latitude];
lon2020  = [DPOL.longitude];
extinc2020  = DPOL.extinc;
%% to load data of year 2020
yyyy = '2021';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2021  = DPOL.dp_ratio;
temp2021 = DPOL.temperature;
lat2021  = [DPOL.latitude];
lon2021  = [DPOL.longitude];
extinc2021  = DPOL.extinc;
%% to load the data of SECOND month of season
m2 = str2num(mm) + 1;
mm2 = num2str(mod(m2,12),'%02d');
%% to load data of year 2014
yyyy = '2014';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);    
dpr2014  = [dpr2014; DPOL.dp_ratio];
temp2014 = [temp2014; DPOL.temperature];
lat2014  = [lat2014; DPOL.latitude];
lon2014  = [lon2014; DPOL.longitude];
extinc2014  = [extinc2014; DPOL.extinc];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);    
dpr2018  = [dpr2018; DPOL.dp_ratio];
temp2018 = [temp2018; DPOL.temperature];
lat2018  = [lat2018; DPOL.latitude];
lon2018  = [lon2018; DPOL.longitude];
extinc2018  = [extinc2018; DPOL.extinc];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2019  = [dpr2019; DPOL.dp_ratio];
temp2019 = [temp2019; DPOL.temperature];
lat2019  = [lat2019; DPOL.latitude];
lon2019  = [lon2019; DPOL.longitude];
extinc2019  = [extinc2019; DPOL.extinc];
%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2020  = [dpr2020; DPOL.dp_ratio];
temp2020 = [temp2020; DPOL.temperature];
lat2020  = [lat2020; DPOL.latitude];
lon2020  = [lon2020; DPOL.longitude];
extinc2020  = [extinc2020; DPOL.extinc];
%% to load data of year 2021
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2021  = [dpr2021; DPOL.dp_ratio];
temp2021 = [temp2021; DPOL.temperature];
lat2021  = [lat2021; DPOL.latitude];
lon2021  = [lon2021; DPOL.longitude];
extinc2021  = [extinc2021; DPOL.extinc];
%% to load the data of THIRD month of season
m3 = str2num(mm) + 2;
mm3 = num2str(mod(m3,12),'%02d');
%% to load data of year 2014
yyyy = '2014';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);    
dpr2014  = [dpr2014; DPOL.dp_ratio];
temp2014 = [temp2014; DPOL.temperature];
lat2014  = [lat2014; DPOL.latitude];
lon2014  = [lon2014; DPOL.longitude];
extinc2014  = [extinc2014; DPOL.extinc];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);    
dpr2018  = [dpr2018; DPOL.dp_ratio];
temp2018 = [temp2018; DPOL.temperature];
lat2018  = [lat2018; DPOL.latitude];
lon2018  = [lon2018; DPOL.longitude];
extinc2018  = [extinc2018; DPOL.extinc];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2019  = [dpr2019; DPOL.dp_ratio];
temp2019 = [temp2019; DPOL.temperature];
lat2019  = [lat2019; DPOL.latitude];
lon2019  = [lon2019; DPOL.longitude];
extinc2019  = [extinc2019; DPOL.extinc];
%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2020  = [dpr2020; DPOL.dp_ratio];
temp2020 = [temp2020; DPOL.temperature];
lat2020  = [lat2020; DPOL.latitude];
lon2020  = [lon2020; DPOL.longitude];
extinc2020  = [extinc2020; DPOL.extinc];
%% to load data of year 2021
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2021  = [dpr2021; DPOL.dp_ratio];
temp2021 = [temp2021; DPOL.temperature];
lat2021  = [lat2021; DPOL.latitude];
lon2021  = [lon2021; DPOL.longitude];
extinc2021  = [extinc2021; DPOL.extinc];
%% height
height = DPOL.height;
%% to remove the points with cidepol < 0.05 and cidepol > 0.85
dprmin = 0.1;
dprmax = 0.8;
for jh = 1:545    
    jnan = find(dpr2014(:,jh) < dprmin | dpr2014(:,jh) > dprmax);
    dpr2014(jnan,jh) = NaN;  
    jnan = find(dpr2018(:,jh) < dprmin | dpr2018(:,jh) > dprmax);
    dpr2018(jnan,jh) = NaN;  
    jnan = find(dpr2019(:,jh) < dprmin | dpr2019(:,jh) > dprmax);
    dpr2019(jnan,jh) = NaN;    
    jnan = find(dpr2020(:,jh) < dprmin | dpr2020(:,jh) > dprmax);
    dpr2020(jnan,jh) = NaN;
    jnan = find(dpr2021(:,jh) < dprmin | dpr2021(:,jh) > dprmax);
    dpr2021(jnan,jh) = NaN;
end
%% to remove data not within the altitudes of 6-13 km
hmin = 1;
hmax = 18;
jhc = find(height > hmin & height < hmax);
jmin = jhc(1) - 1; %% 183 - 4.99;      216 - 5.98
jmax = jhc(end) + 1; %% 405 - 15.1 km    371 - 13.06
dpr2014(:,1:jmin) = NaN; dpr2014(:,jmax:end) = NaN;
dpr2018(:,1:jmin) = NaN; dpr2018(:,jmax:end) = NaN;
dpr2019(:,1:jmin) = NaN; dpr2019(:,jmax:end) = NaN;
dpr2020(:,1:jmin) = NaN; dpr2020(:,jmax:end) = NaN;
dpr2021(:,1:jmin) = NaN; dpr2021(:,jmax:end) = NaN;
%% to remove data with temperature higher than -38 deg
tempmax = -38;
dpr2014(temp2014 > tempmax) = NaN;
dpr2018(temp2018 > tempmax) = NaN;
dpr2019(temp2019 > tempmax) = NaN;
dpr2020(temp2020 > tempmax) = NaN;
dpr2021(temp2021 > tempmax) = NaN;
temp2014(isnan(dpr2014)) = NaN;
temp2018(isnan(dpr2018)) = NaN;
temp2019(isnan(dpr2019)) = NaN;
temp2020(isnan(dpr2020)) = NaN;
temp2021(isnan(dpr2021)) = NaN;
extinc2014(isnan(dpr2014)) = NaN;
extinc2018(isnan(dpr2018)) = NaN;
extinc2019(isnan(dpr2019)) = NaN;
extinc2020(isnan(dpr2020)) = NaN;
extinc2021(isnan(dpr2021)) = NaN;
%% to sort data for ML and HL separated at latitude of 60 deg
hl2014 = find(lat2014 >= 60);
ml2014 = find(lat2014 < 60);
%     dpr2014_hl = dpr2014(hl2014,:);
%     dpr2014_ml = dpr2014(ml2014,:);
    temp2014_hl = temp2014(hl2014,:);
    temp2014_ml = temp2014(ml2014,:);
    extinc2014_hl = extinc2014(hl2014,:);
    extinc2014_ml = extinc2014(ml2014,:);
clear dpr2014 temp2014 extinc2014;
hl2018 = find(lat2018 >= 60);
ml2018 = find(lat2018 < 60);
%     dpr2018_hl = dpr2018(hl2018,:);
%     dpr2018_ml = dpr2018(ml2018,:);
    temp2018_hl = temp2018(hl2018,:);
    temp2018_ml = temp2018(ml2018,:);
    extinc2018_hl = extinc2018(hl2018,:);
    extinc2018_ml = extinc2018(ml2018,:);
clear dpr2018 temp2018 extinc2018 ;
hl2019 = find(lat2019 >= 60);
ml2019 = find(lat2019 < 60);
%     dpr2019_hl = dpr2019(hl2019,:);
%     dpr2019_ml = dpr2019(ml2019,:);
    temp2019_hl = temp2019(hl2019,:);
    temp2019_ml = temp2019(ml2019,:);
    extinc2019_hl = extinc2019(hl2019,:);
    extinc2019_ml = extinc2019(ml2019,:);
clear dpr2019 temp2019 extinc2019 ;
hl2020 = find(lat2020 >= 60);
ml2020 = find(lat2020 < 60);
%     dpr2020_hl = dpr2020(hl2020,:);
%     dpr2020_ml = dpr2020(ml2020,:);
    temp2020_hl = temp2020(hl2020,:);
    temp2020_ml = temp2020(ml2020,:);
    extinc2020_hl = extinc2020(hl2020,:);
    extinc2020_ml = extinc2020(ml2020,:);
clear dpr2020 temp2020 extinc2020 ;
hl2021 = find(lat2021 >= 60);
ml2021 = find(lat2021 < 60);
%     dpr2021_hl = dpr2021(hl2021,:);
%     dpr2021_ml = dpr2021(ml2021,:);
    temp2021_hl = temp2021(hl2021,:);
    temp2021_ml = temp2021(ml2021,:);
    extinc2021_hl = extinc2021(hl2021,:);
    extinc2021_ml = extinc2021(ml2021,:);
clear dpr2021 temp2021 extinc2021 ;  
%% to calculate the occurrence rate of cirrus clouds
nump_ci2014_ml = NaN(size(height));
nump_ci2018_ml = NaN(size(height));
nump_ci2019_ml = NaN(size(height));
nump_ci2020_ml = NaN(size(height));
nump_ci2021_ml = NaN(size(height));

nump_ci2014_hl = NaN(size(height));
nump_ci2018_hl = NaN(size(height));
nump_ci2019_hl = NaN(size(height));
nump_ci2020_hl = NaN(size(height));
nump_ci2021_hl = NaN(size(height));
for jh = 1:545
    j2014 = find(~isnan(extinc2014_ml(:,jh)));
    if isempty(j2014)
        continue
    else
        nump_ci2014_ml(jh) = length(j2014);
    end
    j2018 = find(~isnan(extinc2018_ml(:,jh)));
    if isempty(j2018)
        continue
    else
        nump_ci2018_ml(jh) = length(j2018);
    end
    j2019 = find(~isnan(extinc2019_ml(:,jh)));
    if isempty(j2019)
        continue
    else
        nump_ci2019_ml(jh) = length(j2019);
    end
    j2020 = find(~isnan(extinc2020_ml(:,jh)));
    if isempty(j2020)
        continue
    else
        nump_ci2020_ml(jh) = length(j2020);
    end
    j2021 = find(~isnan(extinc2021_ml(:,jh)));
    if isempty(j2021)
        continue
    else
        nump_ci2021_ml(jh) = length(j2021);
    end
end
for jh = 1:545
    j2014 = find(~isnan(extinc2014_hl(:,jh)));
    if isempty(j2014)
        continue
    else
        nump_ci2014_hl(jh) = length(j2014);
    end
    j2018 = find(~isnan(extinc2018_hl(:,jh)));
    if isempty(j2018)
        continue
    else
        nump_ci2018_hl(jh) = length(j2018);
    end
    j2019 = find(~isnan(extinc2019_hl(:,jh)));
    if isempty(j2019)
        continue
    else
        nump_ci2019_hl(jh) = length(j2019);
    end
    j2020 = find(~isnan(extinc2020_hl(:,jh)));
    if isempty(j2020)
        continue
    else
        nump_ci2020_hl(jh) = length(j2020);
    end
    j2021 = find(~isnan(extinc2021_hl(:,jh)));
    if isempty(j2021)
        continue
    else
        nump_ci2021_hl(jh) = length(j2021);
    end
end

perc2014_ml = nump_ci2014_ml./size(extinc2014_ml,1)*100;
perc2018_ml = nump_ci2018_ml./size(extinc2018_ml,1)*100;
perc2019_ml = nump_ci2019_ml./size(extinc2019_ml,1)*100;
perc2020_ml = nump_ci2020_ml./size(extinc2020_ml,1)*100;
perc2021_ml = nump_ci2021_ml./size(extinc2021_ml,1)*100;
perc2014_hl = nump_ci2014_hl./size(extinc2014_hl,1)*100;
perc2018_hl = nump_ci2018_hl./size(extinc2018_hl,1)*100;
perc2019_hl = nump_ci2019_hl./size(extinc2019_hl,1)*100;
perc2020_hl = nump_ci2020_hl./size(extinc2020_hl,1)*100;
perc2021_hl = nump_ci2021_hl./size(extinc2021_hl,1)*100;
%% to remove the data with occurrence rate smaller than orlim
orlim = 1;
jc2014_hl = find(perc2014_hl < orlim);
jc2018_hl = find(perc2018_hl < orlim);
jc2019_hl = find(perc2019_hl < orlim);
jc2020_hl = find(perc2020_hl < orlim);
jc2021_hl = find(perc2021_hl < orlim);
jc2014_ml = find(perc2014_ml < orlim);
jc2018_ml = find(perc2018_ml < orlim);
jc2019_ml = find(perc2019_ml < orlim);
jc2020_ml = find(perc2020_ml < orlim);
jc2021_ml = find(perc2021_ml < orlim);
%% to remove the results with OR less than orlim %
extinc2014_hl(:,jc2014_hl) = NaN;
extinc2018_hl(:,jc2018_hl) = NaN;
extinc2019_hl(:,jc2019_hl) = NaN;
extinc2020_hl(:,jc2020_hl) = NaN;
extinc2021_hl(:,jc2021_hl) = NaN;

extinc2014_ml(:,jc2014_ml) = NaN;
extinc2018_ml(:,jc2018_ml) = NaN;
extinc2019_ml(:,jc2019_ml) = NaN;
extinc2020_ml(:,jc2020_ml) = NaN;
extinc2021_ml(:,jc2021_ml) = NaN;
%% to calculate the percentiles of each parameter in cirrus clouds
extinc2014_hl_prc = NaN(3,length(height));
extinc2018_hl_prc = NaN(3,length(height));
extinc2019_hl_prc = NaN(3,length(height));
extinc2020_hl_prc = NaN(3,length(height));
extinc2021_hl_prc = NaN(3,length(height));
extinc2014_ml_prc = NaN(3,length(height));
extinc2018_ml_prc = NaN(3,length(height));
extinc2019_ml_prc = NaN(3,length(height));
extinc2020_ml_prc = NaN(3,length(height));
extinc2021_ml_prc = NaN(3,length(height));
extinc2014_hl_prc = prctile(extinc2014_hl,[25 50 75]);
extinc2018_hl_prc = prctile(extinc2018_hl,[25 50 75]);
extinc2019_hl_prc = prctile(extinc2019_hl,[25 50 75]);
extinc2020_hl_prc = prctile(extinc2020_hl,[25 50 75]);
extinc2021_hl_prc = prctile(extinc2021_hl,[25 50 75]);
extinc2014_ml_prc = prctile(extinc2014_ml,[25 50 75]);
extinc2018_ml_prc = prctile(extinc2018_ml,[25 50 75]);
extinc2019_ml_prc = prctile(extinc2019_ml,[25 50 75]);
extinc2020_ml_prc = prctile(extinc2020_ml,[25 50 75]);
extinc2021_ml_prc = prctile(extinc2021_ml,[25 50 75]);

extinc2014_hl_med = nanmedian(extinc2014_hl,1);
extinc2018_hl_med = nanmedian(extinc2018_hl,1);
extinc2019_hl_med = nanmedian(extinc2019_hl,1);
extinc2020_hl_med = nanmedian(extinc2020_hl,1);
extinc2021_hl_med = nanmedian(extinc2021_hl,1);
extinc_5yr_hl_med = nanmedian([extinc2014_hl; extinc2018_hl; extinc2019_hl; extinc2020_hl; extinc2021_hl],1);

extinc2014_ml_med = nanmedian(extinc2014_ml,1);
extinc2018_ml_med = nanmedian(extinc2018_ml,1);
extinc2019_ml_med = nanmedian(extinc2019_ml,1);
extinc2020_ml_med = nanmedian(extinc2020_ml,1);
extinc2021_ml_med = nanmedian(extinc2021_ml,1);
extinc_5yr_ml_med = nanmedian([extinc2014_ml; extinc2018_ml; extinc2019_ml; extinc2020_ml; extinc2021_ml],1);
%% to plot
fz = 12;
cmap_hl = cool(6);
cmap_ml = summer(6);
%%
f1 = figure(1)
set(f1,'units','inch','position',[.3,3,6,6])
hold on
semilogx(smooth(extinc2014_hl_med,11),height,'color',cmap_hl(1,:),'Linewidth',2);
semilogx(smooth(extinc2018_hl_med,11),height,'color',cmap_hl(2,:),'Linewidth',2);
semilogx(smooth(extinc2019_hl_med,11),height,'color',cmap_hl(3,:),'Linewidth',2);
semilogx(smooth(extinc2020_hl_med,11),height,'color',cmap_hl(4,:),'Linewidth',2); 
semilogx(smooth(extinc2021_hl_med,11),height,'color',cmap_hl(5,:),'Linewidth',2); 
semilogx(smooth(extinc_5yr_hl_med,11),height,'color','red','Linewidth',2); 

semilogx(smooth(extinc2014_ml_med,11),height,'color',cmap_ml(1,:),'Linewidth',2);
semilogx(smooth(extinc2018_ml_med,11),height,'color',cmap_ml(2,:),'Linewidth',2);
semilogx(smooth(extinc2019_ml_med,11),height,'color',cmap_ml(3,:),'Linewidth',2);
semilogx(smooth(extinc2020_ml_med,11),height,'color',cmap_ml(4,:),'Linewidth',2); 
semilogx(smooth(extinc2021_ml_med,11),height,'color',cmap_ml(5,:),'Linewidth',2);  
semilogx(smooth(extinc_5yr_ml_med,11),height,'color','black','Linewidth',2); 
set(gca,'xlim',[0.01 1],'FontSize',fz);
set(gca,'xticklabel',{'0.01';'0.10';'1.00'});
set(gca,'ylim',[3 15],'ytick',[1:1:15],'FontSize',fz);
set(gca,'tickdir','out');
legend('2014 HL','2018 HL','2019 HL','2020 HL','2021 HL','5yrs HL','2014 ML','2018 ML','2019 ML','2020 ML','2021 ML','5yrs ML',3);
ylabel('Altitude [km]','fontweight','bold','FontSize',fz);
set(gca,'xscale','log')
xlabel('Extinction coeff. (median) [km^{-1}]','fontweight','bold','FontSize',fz);
if fileext(3) == 'D'
    text(0.04,4.3,['OR < ' num2str(orlim,'%0.1f') '%'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
    text(0.04,3.55,[mm_str ', Day time'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
elseif fileext(2) == 'D' & fileext(3) == 'N'
    text(0.04,4.3,['OR > ' num2str(orlim,'%0.1f') '%'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
    text(0.04,3.55,[mm_str ', Day + night'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
else
    text(0.04,4.3,['OR > ' num2str(orlim,'%0.1f') '%'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
    text(0.04,3.55,[mm_str ', Night time'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
end
hold off

print('-dpng','-painters',['prof_extinc_median_ORlim' num2str(orlim,'%0.1f') '_CirrusHL_' mm_str fileext(1:10) '_5yr.png']);
print(f1, ['prof_extinc_median_ORlim' num2str(orlim,'%0.1f') '_CirrusHL_' mm_str fileext(1:10) '_5yr'], '-dpdf')

%%