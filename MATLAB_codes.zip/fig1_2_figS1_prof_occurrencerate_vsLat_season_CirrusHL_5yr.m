%% this routine is to plot the profiles of occurrence rate in years of 2014, 2018-2021
%% tested under the MATLAB 2010B
clear all; clc; format long; close all
directoryname = pwd;  %% the current folder, where the MATLAB data are stored
fileext    = '_DN_Europe.mat'
% fileext    = '_ZN_Europe.mat'
% fileext    = '_ZD_Europe.mat'
%% to load the data of FIRST month of season
mm = '03';          % to change the number (03, 06, 09, 12) for different season 
mm_str = 'MAM';     % to change the season (MAM, JJA, SON, DJF)
%% to load data of year 2014
yyyy = '2014';
    filename = ['DPOL_extinc_' yyyy '-' mm fileext];
        load([directoryname '\' filename]);
    dpr2014  = DPOL.dp_ratio;
    temp2014 = DPOL.temperature;
    lat2014  = DPOL.latitude;
    lon2014  = DPOL.longitude;
%% to load data of year 2018
yyyy = '2018';
if str2num(mm) > 10    
    dpr2018  = [];
    temp2018 = [];
    lat2018  = [];
    lon2018  = [];
else
    filename = ['DPOL_extinc_' yyyy '-' mm fileext];
        load([directoryname '\' filename]);
    dpr2018  = DPOL.dp_ratio;
    temp2018 = DPOL.temperature;
    lat2018  = DPOL.latitude;
    lon2018  = DPOL.longitude;
end
%% to load data of year 2019
yyyy = '2019';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2019  = DPOL.dp_ratio;
temp2019 = DPOL.temperature;
lat2019  = [DPOL.latitude];
lon2019  = [DPOL.longitude];
%% to load data of year 2020
yyyy = '2020';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2020  = DPOL.dp_ratio;
temp2020 = DPOL.temperature;
lat2020  = [DPOL.latitude];
lon2020  = [DPOL.longitude];
%% to load data of year 2020
yyyy = '2021';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2021  = DPOL.dp_ratio;
temp2021 = DPOL.temperature;
lat2021  = [DPOL.latitude];
lon2021  = [DPOL.longitude];
%% to load the data of SECOND month of season
m2 = str2num(mm) + 1;
mm2 = num2str(mod(m2,12),'%02d');
%% to load data of year 2014
yyyy = '2014';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);    
dpr2014  = [dpr2014; DPOL.dp_ratio];
temp2014 = [temp2014; DPOL.temperature];
lat2014  = [lat2014; DPOL.latitude];
lon2014  = [lon2014; DPOL.longitude];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);    
dpr2018  = [dpr2018; DPOL.dp_ratio];
temp2018 = [temp2018; DPOL.temperature];
lat2018  = [lat2018; DPOL.latitude];
lon2018  = [lon2018; DPOL.longitude];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2019  = [dpr2019; DPOL.dp_ratio];
temp2019 = [temp2019; DPOL.temperature];
lat2019  = [lat2019; DPOL.latitude];
lon2019  = [lon2019; DPOL.longitude];
%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2020  = [dpr2020; DPOL.dp_ratio];
temp2020 = [temp2020; DPOL.temperature];
lat2020  = [lat2020; DPOL.latitude];
lon2020  = [lon2020; DPOL.longitude];
%% to load data of year 2021
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2021  = [dpr2021; DPOL.dp_ratio];
temp2021 = [temp2021; DPOL.temperature];
lat2021  = [lat2021; DPOL.latitude];
lon2021  = [lon2021; DPOL.longitude];
%% to load the data of THIRD month of season
m3 = str2num(mm) + 2;
mm3 = num2str(mod(m3,12),'%02d');
%% to load data of year 2014
yyyy = '2014';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);    
dpr2014  = [dpr2014; DPOL.dp_ratio];
temp2014 = [temp2014; DPOL.temperature];
lat2014  = [lat2014; DPOL.latitude];
lon2014  = [lon2014; DPOL.longitude];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);    
dpr2018  = [dpr2018; DPOL.dp_ratio];
temp2018 = [temp2018; DPOL.temperature];
lat2018  = [lat2018; DPOL.latitude];
lon2018  = [lon2018; DPOL.longitude];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2019  = [dpr2019; DPOL.dp_ratio];
temp2019 = [temp2019; DPOL.temperature];
lat2019  = [lat2019; DPOL.latitude];
lon2019  = [lon2019; DPOL.longitude];
%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2020  = [dpr2020; DPOL.dp_ratio];
temp2020 = [temp2020; DPOL.temperature];
lat2020  = [lat2020; DPOL.latitude];
lon2020  = [lon2020; DPOL.longitude];
%% to load data of year 2021
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2021  = [dpr2021; DPOL.dp_ratio];
temp2021 = [temp2021; DPOL.temperature];
lat2021  = [lat2021; DPOL.latitude];
lon2021  = [lon2021; DPOL.longitude];
%% to remove the points with cidepol < 0.1 and cidepol > 0.8
dprmin = 0.1;
dprmax = 0.8;
for jh = 1:545    
    jnan = find(dpr2018(:,jh) < dprmin | dpr2018(:,jh) > dprmax);
    dpr2018(jnan,jh) = NaN;  
    jnan = find(dpr2019(:,jh) < dprmin | dpr2019(:,jh) > dprmax);
    dpr2019(jnan,jh) = NaN;    
    jnan = find(dpr2020(:,jh) < dprmin | dpr2020(:,jh) > dprmax);
    dpr2020(jnan,jh) = NaN;
    jnan = find(dpr2021(:,jh) < dprmin | dpr2021(:,jh) > dprmax);
    dpr2021(jnan,jh) = NaN;
end
%% height
height = DPOL.height;
%% to remove data not within the altitudes of 6-13 km
hmin = 3;
hmax = 15;
jhc = find(height > hmin & height < hmax);
jmin = jhc(1) - 1; %% 183 - 4.99;      216 - 5.98
jmax = jhc(end) + 1; %% 405 - 15.1 km    371 - 13.06
dpr2014(:,1:jmin) = NaN; dpr2014(:,jmax:end) = NaN;
dpr2018(:,1:jmin) = NaN; dpr2018(:,jmax:end) = NaN;
dpr2019(:,1:jmin) = NaN; dpr2019(:,jmax:end) = NaN;
dpr2020(:,1:jmin) = NaN; dpr2020(:,jmax:end) = NaN;
dpr2021(:,1:jmin) = NaN; dpr2021(:,jmax:end) = NaN;
%% to remove data with temperature higher than tempmax deg
tempmax = -38;
dpr2014(temp2014 > tempmax) = NaN;
dpr2018(temp2018 > tempmax) = NaN;
dpr2019(temp2019 > tempmax) = NaN;
dpr2020(temp2020 > tempmax) = NaN;
dpr2021(temp2021 > tempmax) = NaN;
%% to sort data for ML and HL separated at latitude of 60 deg
hl2014 = find(lat2014 >= 60);
ml2014 = find(lat2014 < 60);
    dpr2014_hl = dpr2014(hl2014,:);
    dpr2014_ml = dpr2014(ml2014,:);
    temp2014_hl = temp2014(hl2014,:);
    temp2014_ml = temp2014(ml2014,:);
hl2018 = find(lat2018 >= 60);
ml2018 = find(lat2018 < 60);
    dpr2018_hl = dpr2018(hl2018,:);
    dpr2018_ml = dpr2018(ml2018,:);
    temp2018_hl = temp2018(hl2018,:);
    temp2018_ml = temp2018(ml2018,:);
hl2019 = find(lat2019 >= 60);
ml2019 = find(lat2019 < 60);
    dpr2019_hl = dpr2019(hl2019,:);
    dpr2019_ml = dpr2019(ml2019,:);
    temp2019_hl = temp2019(hl2019,:);
    temp2019_ml = temp2019(ml2019,:);
hl2020 = find(lat2020 >= 60);
ml2020 = find(lat2020 < 60);
    dpr2020_hl = dpr2020(hl2020,:);
    dpr2020_ml = dpr2020(ml2020,:);
    temp2020_hl = temp2020(hl2020,:);
    temp2020_ml = temp2020(ml2020,:);
hl2021 = find(lat2021 >= 60);
ml2021 = find(lat2021 < 60);
    dpr2021_hl = dpr2021(hl2021,:);
    dpr2021_ml = dpr2021(ml2021,:);
    temp2021_hl = temp2021(hl2021,:);
    temp2021_ml = temp2021(ml2021,:);
%% composite values in 5 yrs
dpr_5yr_hl = [dpr2014_hl; dpr2018_hl; dpr2019_hl; dpr2020_hl; dpr2021_hl ];
dpr_5yr_ml = [dpr2014_ml; dpr2018_ml; dpr2019_ml; dpr2020_ml; dpr2021_ml ];    
%%
length2014_hl = size(dpr2014_hl,1);
length2014_ml = size(dpr2014_ml,1);
length2018_hl = size(dpr2018_hl,1);
length2018_ml = size(dpr2018_ml,1);
length2019_hl = size(dpr2019_hl,1);
length2019_ml = size(dpr2019_ml,1);
length2020_hl = size(dpr2020_hl,1);
length2020_ml = size(dpr2020_ml,1);
length2021_hl = size(dpr2021_hl,1);
length2021_ml = size(dpr2021_ml,1);
length_5yr_hl = size(dpr_5yr_hl,1);
length_5yr_ml = size(dpr_5yr_ml,1);
hof2014_hl = NaN(size(height));
hof2014_ml = NaN(size(height));
hof2018_hl = NaN(size(height));
hof2018_ml = NaN(size(height));
hof2019_hl = NaN(size(height));
hof2019_ml = NaN(size(height));
hof2020_hl = NaN(size(height));
hof2020_ml = NaN(size(height));
hof2021_hl = NaN(size(height));
hof2021_ml = NaN(size(height));
hof_5yr_hl = NaN(size(height));
hof_5yr_ml = NaN(size(height));

for hh = 1:length(height) % height(216) = 5.98 km
    hof2014_hl(hh) = length(find(~isnan(dpr2014_hl(:,hh))))/length2014_hl*100;
    hof2014_ml(hh) = length(find(~isnan(dpr2014_ml(:,hh))))/length2014_ml*100;
    hof2018_hl(hh) = length(find(~isnan(dpr2018_hl(:,hh))))/length2018_hl*100;
    hof2018_ml(hh) = length(find(~isnan(dpr2018_ml(:,hh))))/length2018_ml*100;
    hof2019_hl(hh) = length(find(~isnan(dpr2019_hl(:,hh))))/length2019_hl*100;
    hof2019_ml(hh) = length(find(~isnan(dpr2019_ml(:,hh))))/length2019_ml*100;
    hof2020_hl(hh) = length(find(~isnan(dpr2020_hl(:,hh))))/length2020_hl*100;
    hof2020_ml(hh) = length(find(~isnan(dpr2020_ml(:,hh))))/length2020_ml*100;
    hof2021_hl(hh) = length(find(~isnan(dpr2021_hl(:,hh))))/length2021_hl*100;
    hof2021_ml(hh) = length(find(~isnan(dpr2021_ml(:,hh))))/length2021_ml*100;
    hof_5yr_hl(hh) = length(find(~isnan(dpr_5yr_hl(:,hh))))/length_5yr_hl*100;
    hof_5yr_ml(hh) = length(find(~isnan(dpr_5yr_ml(:,hh))))/length_5yr_ml*100;
end
hof2014_hl(find(hof2014_hl < 0.01)) = NaN;
hof2018_hl(find(hof2018_hl < 0.01)) = NaN;
hof2019_hl(find(hof2019_hl < 0.01)) = NaN;
hof2020_hl(find(hof2020_hl < 0.01)) = NaN;
hof2021_hl(find(hof2021_hl < 0.01)) = NaN;
hof2014_ml(find(hof2014_ml < 0.01)) = NaN;
hof2018_ml(find(hof2018_ml < 0.01)) = NaN;
hof2019_ml(find(hof2019_ml < 0.01)) = NaN;
hof2020_ml(find(hof2020_ml < 0.01)) = NaN;
hof2021_ml(find(hof2021_ml < 0.01)) = NaN;
hof_mean_hl = nanmean([hof2014_hl; hof2018_hl; hof2019_hl; hof2020_hl; hof2021_hl ]);
hof_std_hl = nanstd([hof2014_hl; hof2018_hl; hof2019_hl; hof2020_hl; hof2021_hl ]);
hof_mean_ml = nanmean([hof2014_ml; hof2018_ml; hof2019_ml; hof2020_ml; hof2021_ml ]);
hof_std_ml = nanstd([hof2014_ml; hof2018_ml; hof2019_ml; hof2020_ml; hof2021_ml ]);

hof_mean_hl4yr = nanmean([hof2018_hl; hof2019_hl; hof2020_hl; hof2021_hl ]);
hof_std_hl4yr = nanstd([hof2018_hl; hof2019_hl; hof2020_hl; hof2021_hl ]);
hof_mean_ml4yr = nanmean([hof2018_ml; hof2019_ml; hof2020_ml; hof2021_ml ]);
hof_std_ml4yr = nanstd([hof2018_ml; hof2019_ml; hof2020_ml; hof2021_ml ]);
%% to calculate the occurrence rate in different latitudes
lat_stp = 35:5:80; %% steps of latitude

istp = length(lat_stp) - 1;
hof2014_lat = NaN(istp, length(height));
hof2018_lat = NaN(istp, length(height));
hof2019_lat = NaN(istp, length(height));
hof2020_lat = NaN(istp, length(height));
hof2021_lat = NaN(istp, length(height));

for jl = 1:istp
    idx_lat2014 = find(lat2014 >= lat_stp(jl) & lat2014 < lat_stp(jl + 1));
    idx_lat2018 = find(lat2018 >= lat_stp(jl) & lat2018 < lat_stp(jl + 1));
    idx_lat2019 = find(lat2019 >= lat_stp(jl) & lat2019 < lat_stp(jl + 1));
    idx_lat2020 = find(lat2020 >= lat_stp(jl) & lat2020 < lat_stp(jl + 1));
    idx_lat2021 = find(lat2021 >= lat_stp(jl) & lat2021 < lat_stp(jl + 1));
    for jh = 1:length(height) 
        hof2014_lat(jl,jh) = length(find(~isnan(dpr2014(idx_lat2014,jh))))/length(idx_lat2014)*100;
        hof2018_lat(jl,jh) = length(find(~isnan(dpr2018(idx_lat2018,jh))))/length(idx_lat2018)*100;
        hof2019_lat(jl,jh) = length(find(~isnan(dpr2019(idx_lat2019,jh))))/length(idx_lat2019)*100;
        hof2020_lat(jl,jh) = length(find(~isnan(dpr2020(idx_lat2020,jh))))/length(idx_lat2020)*100;
        hof2021_lat(jl,jh) = length(find(~isnan(dpr2021(idx_lat2021,jh))))/length(idx_lat2021)*100;
    end
end
hof1421_lat = (hof2014_lat + hof2018_lat + hof2019_lat + hof2020_lat + hof2021_lat)/5;
% 
% hci2014_hl = findHCirrus(dpr2014_hl,height);
% hci2014_ml = findHCirrus(dpr2014_ml,height);
% hci2018_hl = findHCirrus(dpr2018_hl,height);
% hci2018_ml = findHCirrus(dpr2018_ml,height);
% hci2019_hl = findHCirrus(dpr2019_hl,height);
% hci2019_ml = findHCirrus(dpr2019_ml,height);
% hci2020_hl = findHCirrus(dpr2020_hl,height);
% hci2020_ml = findHCirrus(dpr2020_ml,height);
% hci2021_hl = findHCirrus(dpr2021_hl,height);
% hci2021_ml = findHCirrus(dpr2021_ml,height);

orlim = 1;
jc2014_lat = NaN(istp, length(height));
jc2018_lat = NaN(istp, length(height));
jc2019_lat = NaN(istp, length(height));
jc2020_lat = NaN(istp, length(height));
jc2021_lat = NaN(istp, length(height));
jc1421_lat = NaN(istp, length(height));

h_maxor2014_lat = NaN(istp, 6);
h_maxor2018_lat = NaN(istp, 6);
h_maxor2019_lat = NaN(istp, 6);
h_maxor2020_lat = NaN(istp, 6);
h_maxor2021_lat = NaN(istp, 6);
h_maxor1421_lat = NaN(istp, 6);
for j = 1:istp
    jc2014_lat(j,find(hof2014_lat(j,:) > orlim)) = 1;
    jc2018_lat(j,find(hof2018_lat(j,:) > orlim)) = 1;
    jc2019_lat(j,find(hof2019_lat(j,:) > orlim)) = 1;
    jc2020_lat(j,find(hof2020_lat(j,:) > orlim)) = 1;
    jc2021_lat(j,find(hof2021_lat(j,:) > orlim)) = 1;
    jc1421_lat(j,find(hof1421_lat(j,:) > orlim)) = 1;
    [mx jmx] = max(smooth(hof2014_lat(j,:),9));
    jnonnan2014 = find(~isnan(jc2014_lat(j,:)));
    h_maxor2014_lat(j,:) = [mx jmx height(jmx) height(jnonnan2014(1)) height(jnonnan2014(end)) height(jnonnan2014(end))-height(jnonnan2014(1))];
    [mx jmx] = max(smooth(hof2018_lat(j,:),9));
    jnonnan2018 = find(~isnan(jc2018_lat(j,:)));
    h_maxor2018_lat(j,:) = [mx jmx height(jmx) height(jnonnan2018(1)) height(jnonnan2018(end)) height(jnonnan2018(end))-height(jnonnan2018(1))];
    [mx jmx] = max(smooth(hof2019_lat(j,:),9));
    jnonnan2019 = find(~isnan(jc2019_lat(j,:)));
    h_maxor2019_lat(j,:) = [mx jmx height(jmx) height(jnonnan2019(1)) height(jnonnan2019(end)) height(jnonnan2019(end))-height(jnonnan2019(1))];
    [mx jmx] = max(smooth(hof2020_lat(j,:),9));
    jnonnan2020 = find(~isnan(jc2020_lat(j,:)));
    h_maxor2020_lat(j,:) = [mx jmx height(jmx) height(jnonnan2020(1)) height(jnonnan2020(end)) height(jnonnan2020(end))-height(jnonnan2020(1))];
    [mx jmx] = max(smooth(hof2021_lat(j,:),9));
    jnonnan2021 = find(~isnan(jc2021_lat(j,:)));
    h_maxor2021_lat(j,:) = [mx jmx height(jmx) height(jnonnan2021(1)) height(jnonnan2021(end)) height(jnonnan2021(end))-height(jnonnan2021(1))];
    [mx jmx] = max(smooth(hof1421_lat(j,:),21));
    jnonnan1421 = find(~isnan(jc1421_lat(j,:)));
    h_maxor1421_lat(j,:) = [mx jmx height(jmx) height(jnonnan1421(1)) height(jnonnan1421(end)) height(jnonnan1421(end))-height(jnonnan1421(1))];
end

h_maxor = [2014 orlim 1 1 1 1;	h_maxor2014_lat;	2018 orlim 2 2 2 2;	h_maxor2018_lat;	2019 orlim 3 3 3 3;	h_maxor2019_lat;	2020 orlim 4 4 4 4;	h_maxor2020_lat;	2021 orlim 5 5 5 5;	h_maxor2021_lat; 	1421 orlim 6 6 6 6;	h_maxor1421_lat];
csvwrite(['hmaxor_orlim_' num2str(orlim) '_' mm_str '.csv'],h_maxor)

len2014_lat = NaN(istp, 1);
len2018_lat = NaN(istp, 1);
len2019_lat = NaN(istp, 1);
len2020_lat = NaN(istp, 1);
len2021_lat = NaN(istp, 1);
len1421_lat = NaN(istp, 1);
for k = 1:istp
    len2014_lat(k) = length(find(~isnan(jc2014_lat(k,:))));
    len2018_lat(k) = length(find(~isnan(jc2018_lat(k,:))));
    len2019_lat(k) = length(find(~isnan(jc2019_lat(k,:))));
    len2020_lat(k) = length(find(~isnan(jc2020_lat(k,:))));
    len2021_lat(k) = length(find(~isnan(jc2021_lat(k,:))));
    len1421_lat(k) = length(find(~isnan(jc1421_lat(k,:))));
end
jtop_2014 = NaN(istp, 1);
jtop_2018 = NaN(istp, 1);
jtop_2019 = NaN(istp, 1);
jtop_2020 = NaN(istp, 1);
jtop_2021 = NaN(istp, 1);
jtop_1421 = NaN(istp, 1);
jbot_2014 = NaN(istp, 1);
jbot_2018 = NaN(istp, 1);
jbot_2019 = NaN(istp, 1);
jbot_2020 = NaN(istp, 1);
jbot_2021 = NaN(istp, 1);
jbot_1421 = NaN(istp, 1);
for m = 1:istp
    jnan = find(~isnan(jc2014_lat(m,:)));
    jtop_2014(m) = height(max(jnan));
    jbot_2014(m) = height(min(jnan));
    jnan = find(~isnan(jc2018_lat(m,:)));
    jtop_2018(m) = height(max(jnan));
    jbot_2018(m) = height(min(jnan));
    jnan = find(~isnan(jc2019_lat(m,:)));
    jtop_2019(m) = height(max(jnan));
    jbot_2019(m) = height(min(jnan));
    jnan = find(~isnan(jc2020_lat(m,:)));
    jtop_2020(m) = height(max(jnan));
    jbot_2020(m) = height(min(jnan));
    jnan = find(~isnan(jc2021_lat(m,:)));
    jtop_2021(m) = height(max(jnan));
    jbot_2021(m) = height(min(jnan));
    jnan = find(~isnan(jc1421_lat(m,:)));
    jtop_1421(m) = height(max(jnan));
    jbot_1421(m) = height(min(jnan));
end
%% to plot
fz = 12;
cmap_mor = parula(7);
%%
f11 = figure(11); 
set(f11,'units','inch','position',[.3,3,8,6])
hold on
for j = 1:istp
    plot(ceil(jc2014_lat(j,:))*36+(j-1)*5,height,'-','color',cmap_mor(1,:),'Linewidth',2);
    plot(ceil(jc2018_lat(j,:))*36.5+(j-1)*5,height,'-','color',cmap_mor(2,:),'Linewidth',2);
    plot(ceil(jc2019_lat(j,:))*37+(j-1)*5,height,'-','color',cmap_mor(3,:),'Linewidth',2);
    plot(ceil(jc2020_lat(j,:))*37.5+(j-1)*5,height,'-','color',cmap_mor(4,:),'Linewidth',2);
    plot(ceil(jc2021_lat(j,:))*38+(j-1)*5,height,'-','color',cmap_mor(5,:),'Linewidth',2);
    plot(ceil(jc2021_lat(j,:))*38.5+(j-1)*5,height,'-','color',cmap_mor(6,:),'Linewidth',2);
    plot(ceil(jc2014_lat(j,h_maxor2014_lat(j,2)))*36+(j-1)*5,  height(h_maxor2014_lat(j,2)),'o','color',cmap_mor(1,:),'Linewidth',2)
    plot(ceil(jc2018_lat(j,h_maxor2018_lat(j,2)))*36.5+(j-1)*5,height(h_maxor2018_lat(j,2)),'o','color',cmap_mor(2,:),'Linewidth',2)
    plot(ceil(jc2019_lat(j,h_maxor2019_lat(j,2)))*37+(j-1)*5,  height(h_maxor2019_lat(j,2)),'o','color',cmap_mor(3,:),'Linewidth',2)
    plot(ceil(jc2020_lat(j,h_maxor2020_lat(j,2)))*37.5+(j-1)*5,height(h_maxor2020_lat(j,2)),'o','color',cmap_mor(4,:),'Linewidth',2)
    plot(ceil(jc2021_lat(j,h_maxor2021_lat(j,2)))*38+(j-1)*5,  height(h_maxor2021_lat(j,2)),'o','color',cmap_mor(5,:),'Linewidth',2)
    plot(ceil(jc1421_lat(j,h_maxor1421_lat(j,2)))*38.5+(j-1)*5,height(h_maxor1421_lat(j,2)),'o','color',cmap_mor(6,:),'Linewidth',2)
end
leg = legend('2014','2018','2019','2020','2021','5 yrs',1);
set(leg,'color','none');
set(gca,'ylim',[3 16],'ytick',[3:1:20],'FontSize',fz);
set(gca,'xlim',[35 80],'xtick',[35:5:80],'FontSize',fz);
ylabel('Height of cirrus clouds [km]','Fontweight','bold','FontSize',fz);
xlabel('Latitude [\circ]','Fontweight','bold','FontSize',fz);
if fileext(3) == 'D'
    text(36,4.8,[mm_str(1:3) ', ZD'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
    text(36,4.1,['T < ' num2str(tempmax) ' \circC'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
    text(36,3.4,['OR > ' num2str(orlim) ' %'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
elseif fileext(2) == 'D'
    text(36,4.8,[mm_str(1:3) ', DN' ],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
    text(36,4.1,['T < ' num2str(tempmax) ' \circC'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
    text(36,3.4,['OR > ' num2str(orlim) ' %'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
else
    text(36,4.8,[mm_str(1:3) ', ZN' ],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
    text(36,4.1,['T < ' num2str(tempmax) ' \circC'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
    text(36,3.4,['OR > ' num2str(orlim) ' %'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
end
set(gca,'tickdir','out');
hold off
print('-dpng','-painters',['hgt_cirrus_maxor_vsLat_CirrusHL_T' num2str(tempmax) '_ORlim' num2str(orlim) '_' mm_str fileext(1:10) '_5yr_parula.png']);
figname = ['hgt_cirrus_maxor_vsLat_CirrusHL_T' num2str(tempmax) '_ORlim' num2str(orlim) '_' mm_str fileext(1:10) '_5yr_parula'];

print(gcf, figname, '-dpdf')
saveas(gcf,figname,'fig');
%%
isth = 29;
[maxor_hl imax_hl] = max(smooth(hof_mean_hl,isth));
[maxor_ml imax_ml] = max(smooth(hof_mean_ml,9));
maxor_hl
maxor_ml
hdif = height(imax_ml) - height(imax_hl)

maxor = [maxor_hl  maxor_ml height(imax_hl)  height(imax_ml)];
csvwrite(['maxor_hgt_HLvsML_5yr_' mm_str '.csv'],maxor);

f21 = figure(21); 
set(f21,'units','inch','position',[.3,.7,4,6])
hold on;  
% plot(smooth(hof_5yr_hl,9),height,'color',[1.000000000000000   0.750000000000000   0.792968750000000],'Linewidth',2); 
% plot(smooth(hof_5yr_ml,9),height,'color',[0.5 0.5 0.5],'Linewidth',2); 
plot(smooth(hof_mean_hl,isth),height,'r','Linewidth',2); 
plot(smooth(hof_mean_ml,9),height,'k','Linewidth',2); 
plot(smooth(hof_mean_hl - hof_std_hl,isth),height,'r--','Linewidth',2); 
plot(smooth(hof_mean_ml - hof_std_ml,9),height,'k--','Linewidth',2); 
plot(smooth(hof_mean_hl + hof_std_hl,isth),height,'r--','Linewidth',2); 
plot(smooth(hof_mean_ml + hof_std_ml,9),height,'k--','Linewidth',2); 

set(gca,'ylim',[3 16],'ytick',[2:1:16],'FontSize',fz);
if str2num(mm) == 12
    set(gca,'xlim',[0 20],'xtick',[0:2:20 22],'FontSize',fz);
else
    set(gca,'xlim',[0 16],'xtick',[0:2:16],'FontSize',fz);
end
leg = legend('5 yrs, HL','5 yrs, ML',1);
set(leg,'color','none');
ylabel('Altitude [km]','Fontweight','bold','FontSize',fz);
xlabel('Occurrence rate [%]','Fontweight','bold','FontSize',fz);
set(gca,'tickdir','out');
% set(gca,'xminortick','on')
if fileext(3) == 'D'
    text(8,4.6,[mm_str(1:3) ', Day time'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
    text(8,3.8,['T < ' num2str(tempmax) ' \circC'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
elseif fileext(2) == 'D'
    text(7.8,4.6,[mm_str(1:3) ', Day + Ngt' ],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
    text(7.8,3.8,['T < ' num2str(tempmax) ' \circC'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
else
    text(8,4.6,[mm_str(1:3) ', Night time' ],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
    text(8,3.8,['T < ' num2str(tempmax) ' \circC'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
end
% text(5.2,6.2,'Europe','backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
hold off

print('-dpng','-painters',['prof_mean_occurrate_cirrus_CirrusHL_T' num2str(tempmax) '_' mm_str fileext(1:10) '_5yr_blackred_narrow.png']);
print(f21, ['prof_mean_occurrate_cirrus_CirrusHL_T' num2str(tempmax) '_' mm_str fileext(1:10) '_5yr_blackred_narrow'], '-dpdf')

figname = ['prof_mean_occurrate_cirrus_CirrusHL_T' num2str(tempmax) '_' mm_str fileext(1:10) '_5yr_blackred_narrow'];
saveas(gcf,figname,'fig');
%%
%%
jsm = 21;
cmap = parula(7);
f301 = figure(301)
set(f301,'units','inch','position',[.3,3,8,6])
subplot(2,3,1)
hold on
for jl = 1:istp 
    plot(smooth(hof2014_lat(jl,:),jsm)+(jl-1)*3,height,'color',cmap(1,:),'Linewidth',2);
    line([(jl-1)*3  (jl-1)*3],[0 20],'color',[0.5 0.5 0.5],'linestyle','--','Linewidth',1);
end
ylabel('Altitude [km]','FontSize',fz);
xlabel('Latitude [\circ] / OR [%], 2014','FontSize',fz);
set(gca,'tickdir','out');
set(gca,'xminortick','on')
set(gca,'ylim',[3 15],'ytick',[3:2:20],'FontSize',fz);
if str2num(mm) < 3 | str2num(mm) >= 11 %% if month Jan Feb Mar Nov and Dec
    set(gca,'xlim',[-2 42],'xtick',[0:6:24],'FontSize',fz);
elseif str2num(mm) <= 8 & str2num(mm) >= 6 %% if month Jun Jul Aug
    set(gca,'xlim',[-2 32],'xtick',[0:6:24],'FontSize',fz);
elseif str2num(mm) <= 5 & str2num(mm) >= 3 %% if month Mar Apr May
    set(gca,'xlim',[-2 38],'xtick',[0:6:24],'FontSize',fz);
else
    set(gca,'xlim',[-2 40],'xtick',[0:6:24],'FontSize',fz);
end    
set(gca,'xticklabel',{'35';'45';'55';'65';'75';});
if fileext(3) == 'D'
    title([mm_str(1:3) ', Day time, T < ' num2str(tempmax) ' \circC'],'FontSize',fz);
elseif fileext(2) == 'D'
    title([mm_str(1:3) ', Day + Ngt, T < ' num2str(tempmax) ' \circC'],'FontSize',fz);
else
    title([mm_str(1:3) ', Ngt time, T < ' num2str(tempmax) ' \circC'],'FontSize',fz);
end
hold off
subplot(2,3,2)
hold on
for jl = 1:istp 
    plot(smooth(hof2018_lat(jl,:),jsm)+(jl-1)*3,height,'color',cmap(2,:),'Linewidth',2);
    line([(jl-1)*3  (jl-1)*3],[0 20],'color',[0.5 0.5 0.5],'linestyle','--','Linewidth',1);
end
% ylabel('Altitude [km]','FontSize',fz);
xlabel('Latitude [\circ] / OR [%], 2018','FontSize',fz);
set(gca,'tickdir','out');
set(gca,'xminortick','on')
set(gca,'ylim',[3 15],'ytick',[3:2:20],'FontSize',fz);
if str2num(mm) < 3 | str2num(mm) >= 11 %% if month Jan Feb Mar Nov and Dec
    set(gca,'xlim',[-2 42],'xtick',[0:6:24],'FontSize',fz);
elseif str2num(mm) <= 8 & str2num(mm) >= 6 %% if month Jun Jul Aug
    set(gca,'xlim',[-2 32],'xtick',[0:6:24],'FontSize',fz);
elseif str2num(mm) <= 5 & str2num(mm) >= 3 %% if month Mar Apr May
    set(gca,'xlim',[-2 38],'xtick',[0:6:24],'FontSize',fz);
else
    set(gca,'xlim',[-2 40],'xtick',[0:6:24],'FontSize',fz);
end    
set(gca,'xticklabel',{'35';'45';'55';'65';'75';});
hold off
subplot(2,3,3)
hold on
for jl = 1:istp 
    plot(smooth(hof2019_lat(jl,:),jsm)+(jl-1)*3,height,'color',cmap(3,:),'Linewidth',2);
    line([(jl-1)*3  (jl-1)*3],[0 20],'color',[0.5 0.5 0.5],'linestyle','--','Linewidth',1);
end
% ylabel('Altitude [km]','FontSize',fz);
xlabel('Latitude [\circ] / OR [%], 2019','FontSize',fz);
set(gca,'tickdir','out');
set(gca,'xminortick','on')
set(gca,'ylim',[3 15],'ytick',[3:2:20],'FontSize',fz);
if str2num(mm) < 3 | str2num(mm) >= 11 %% if month Jan Feb Mar Nov and Dec
    set(gca,'xlim',[-2 42],'xtick',[0:6:24],'FontSize',fz);
elseif str2num(mm) <= 8 & str2num(mm) >= 6 %% if month Jun Jul Aug
    set(gca,'xlim',[-2 32],'xtick',[0:6:24],'FontSize',fz);
elseif str2num(mm) <= 5 & str2num(mm) >= 3 %% if month Mar Apr May
    set(gca,'xlim',[-2 38],'xtick',[0:6:24],'FontSize',fz);
else
    set(gca,'xlim',[-2 40],'xtick',[0:6:24],'FontSize',fz);
end    
set(gca,'xticklabel',{'35';'45';'55';'65';'75';});
    hold off
subplot(2,3,4)
hold on
for jl = 1:istp 
    line([(jl-1)*3  (jl-1)*3],[0 20],'color',[0.5 0.5 0.5],'linestyle','--','Linewidth',1);
    plot(smooth(hof2020_lat(jl,:),jsm)+(jl-1)*3,height,'color',cmap(4,:),'Linewidth',2); 
end
ylabel('Altitude [km]','FontSize',fz);
xlabel('Latitude [\circ] / OR [%], 2020','FontSize',fz);
set(gca,'tickdir','out');
set(gca,'xminortick','on')
set(gca,'ylim',[3 15],'ytick',[3:2:20],'FontSize',fz);
if str2num(mm) < 3 | str2num(mm) >= 11 %% if month Jan Feb Mar Nov and Dec
    set(gca,'xlim',[-2 42],'xtick',[0:6:24],'FontSize',fz);
elseif str2num(mm) <= 8 & str2num(mm) >= 6 %% if month Jun Jul Aug
    set(gca,'xlim',[-2 32],'xtick',[0:6:24],'FontSize',fz);
elseif str2num(mm) <= 5 & str2num(mm) >= 3 %% if month Mar Apr May
    set(gca,'xlim',[-2 38],'xtick',[0:6:24],'FontSize',fz);
else
    set(gca,'xlim',[-2 40],'xtick',[0:6:24],'FontSize',fz);
end     
set(gca,'xticklabel',{'35';'45';'55';'65';'75';});
    hold off
    
subplot(2,3,5)
hold on
for jl = 1:istp 
    line([(jl-1)*3  (jl-1)*3],[0 20],'color',[0.5 0.5 0.5],'linestyle','--','Linewidth',1);
    plot(smooth(hof2021_lat(jl,:),jsm)+(jl-1)*3,height,'color',cmap(5,:),'Linewidth',2); 
end
% ylabel('Altitude [km]','FontSize',fz);
xlabel('Latitude [\circ] / OR [%], 2021','FontSize',fz);
set(gca,'tickdir','out');
set(gca,'xminortick','on')
set(gca,'ylim',[3 15],'ytick',[3:2:20],'FontSize',fz);
if str2num(mm) < 3 | str2num(mm) >= 11 %% if month Jan Feb Mar Nov and Dec
    set(gca,'xlim',[-2 42],'xtick',[0:6:24],'FontSize',fz);
elseif str2num(mm) <= 8 & str2num(mm) >= 6 %% if month Jun Jul Aug
    set(gca,'xlim',[-2 32],'xtick',[0:6:24],'FontSize',fz);
elseif str2num(mm) <= 5 & str2num(mm) >= 3 %% if month Mar Apr May
    set(gca,'xlim',[-2 38],'xtick',[0:6:24],'FontSize',fz);
else
    set(gca,'xlim',[-2 40],'xtick',[0:6:24],'FontSize',fz);
end      
set(gca,'xticklabel',{'35';'45';'55';'65';'75';});
    hold off
    
subplot(2,3,6)
hold on
for jl = 1:istp 
    line([(jl-1)*3  (jl-1)*3],[0 20],'color',[0.5 0.5 0.5],'linestyle','--','Linewidth',1);
    plot(smooth(hof1421_lat(jl,:),jsm)+(jl-1)*3,height,'color',cmap(6,:),'Linewidth',2); 
end
% ylabel('Altitude [km]','FontSize',fz);
xlabel('Latitude [\circ] / OR [%], 2014-2021','FontSize',fz);
set(gca,'tickdir','out');
set(gca,'xminortick','on')
set(gca,'ylim',[3 15],'ytick',[3:2:20],'FontSize',fz);
if str2num(mm) < 3 | str2num(mm) >= 11 %% if month Jan Feb Mar Nov and Dec
    set(gca,'xlim',[-2 42],'xtick',[0:6:24],'FontSize',fz);
elseif str2num(mm) <= 8 & str2num(mm) >= 6 %% if month Jun Jul Aug
    set(gca,'xlim',[-2 32],'xtick',[0:6:24],'FontSize',fz);
elseif str2num(mm) <= 5 & str2num(mm) >= 3 %% if month Mar Apr May
    set(gca,'xlim',[-2 38],'xtick',[0:6:24],'FontSize',fz);
else
    set(gca,'xlim',[-2 40],'xtick',[0:6:24],'FontSize',fz);
end     
set(gca,'xticklabel',{'35';'45';'55';'65';'75';});
hold off
    
print('-dpng','-painters',['prof_occurrate_vsLat_CirrusHL_T' num2str(tempmax) '_' mm_str(1:3) fileext(1:10) '_5yr_parula.png']);
print(f301, ['prof_occurrate_vsLat_CirrusHL_T' num2str(tempmax) '_' mm_str(1:3) fileext(1:10) '_5yr_parula'], '-dpdf')

figname = ['prof_occurrate_vsLat_CirrusHL_T' num2str(tempmax) '_' mm_str(1:3) fileext(1:10) '_5yr_parula'];
saveas(gcf,figname,'fig');
% %%