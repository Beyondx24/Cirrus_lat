%% to compare the geometrical thicknesses in HL and ML in different seasons
%% tested under the MATLAB 2010B
clear all; clc; format long; close all
foldername = pwd;  %% the current folder, where the ASCII files are stored
DIR = dir([foldername '\*_DN.csv']);
%% to load data of occurrence frequency of cloud thickness
thickof_sum = [];
for i = 1:length(DIR)
    filename = DIR(i).name;
    thickof = csvread([foldername '\' filename],0);
    thickof_sum = [thickof_sum; thickof];
    mm_str(i,:) = filename(11:13);
end
fileext = filename(14:end);
thickof_5yr_mean = thickof_sum(1:4,7);
%% to plot
fz = 12;
for i = 1:4    
    thickof2014_hl = thickof_sum((i-1)*8+1:(i-1)*8+4,2);
    thickof2018_hl = thickof_sum((i-1)*8+1:(i-1)*8+4,3);
    thickof2019_hl = thickof_sum((i-1)*8+1:(i-1)*8+4,4);
    thickof2020_hl = thickof_sum((i-1)*8+1:(i-1)*8+4,5);
    thickof2021_hl = thickof_sum((i-1)*8+1:(i-1)*8+4,6);
    thickof_5yr_hl = thickof_sum((i-1)*8+1:(i-1)*8+4,7);
    thickof2014_ml = thickof_sum((i-1)*8+5:(i-1)*8+8,2);
    thickof2018_ml = thickof_sum((i-1)*8+5:(i-1)*8+8,3);
    thickof2019_ml = thickof_sum((i-1)*8+5:(i-1)*8+8,4);
    thickof2020_ml = thickof_sum((i-1)*8+5:(i-1)*8+8,5);
    thickof2021_ml = thickof_sum((i-1)*8+5:(i-1)*8+8,6);
    thickof_5yr_ml = thickof_sum((i-1)*8+5:(i-1)*8+8,7);
end
    
%%
    fn = figure(10)
    set(fn,'units','inch','position',[.3,.7,8,6])
for i = 1:4
    thickof_hl_mean = thickof_sum((i-1)*8+1:(i-1)*8+4,7);
    thickof_hl_std = thickof_sum((i-1)*8+1:(i-1)*8+4,8);
    thickof_ml_mean = thickof_sum((i-1)*8+5:(i-1)*8+8,7);
    thickof_ml_std = thickof_sum((i-1)*8+5:(i-1)*8+8,8);
    subplot(1,4,i)
    b = bar((1:4),[thickof_ml_mean'; thickof_hl_mean'; ]',0.8,'grouped');
    colormap(redblue)
    hold on
    thickofbar = [thickof_ml_mean'; thickof_hl_mean'; ]';
    thickoferr = [thickof_ml_std'; thickof_hl_std'; ]';
    [ngroups, nbars] = size(thickofbar);
    groupwidth = min(0.8,nbars/(nbars+1.5));
    for j = 1:nbars
        x = (1-ngroups) - groupwidth/2 + (2*j-1)*groupwidth/(2*nbars);
        errorbar((1:4)+sign(j-1.5)*0.145,thickofbar(:,j),thickoferr(:,j),'k','linestyle','none','Linewidth',1);
    end
    set(gca,'ylim',[0 50],'FontSize',fz);
    set(gca,'xlim',[0.3 4.7],'FontSize',fz);
    set(gca,'xticklabel',{'0.1';'0.3';'1.0';'2.0'});
%     xticklabel_rotate([],45,[],'Fontsize',fz)
    set(gca,'tickdir','out');
    ylabel('Occurrence frequency [%]','FontWeight','bold','FontSize',15);
    if i == 2
        xlabel('Geometrical thickness [km]','FontWeight','bold','FontSize',15);
    end
    text(2.5,48.3,[mm_str(i,:) ', ' fileext(2:3)],'backgroundcolor',[0.8 0.8 0.8],'fontsize',fz,'color','k');
end
jointfig(fn,1,4)
leg = legend('ML','HL');
rect = [0.291, 0.780, .05, .05];
set(leg, 'Position', rect);

    print('-dpng','-painters',['hist_occfreq_HLvsML_thickness_CirrusHL_season' fileext(1:3) '_5yrs.png']);
    print(fn, ['boxplot_occfreq_HLvsML_thickness_CirrusHL_season' fileext(1:3) '_5yrs'], '-dpdf')

    figname = ['boxplot_occfreq_HLvsML_thickness_CirrusHL_season' fileext(1:3) '_5yrs'];
    saveas(gcf,figname,'fig');

