%% this routine is to display the distribution of temperature inside cirrus clouds in different seasons in years of 2014 and 2018-2021
%% tested under the MATLAB 2010B
clear all; clc; format long; close all
directoryname = pwd;  %% the current folder, where the MATLAB data are stored

fileext    = '_DN_Europe.mat';
% fileext    = '_ZN_Europe.mat';
%% to load the data of FIRST month of season
mm = '03';          % to change the number (03, 06, 09, 12) for different season 
mm_str = 'MAM';     % to change the season (MAM, JJA, SON, DJF)
drtar = 'dp_ratio'; % drtar - depol of target
%% to load data of year 2014
yyyy = '2014';
    filename = ['DPOL_extinc_' yyyy '-' mm fileext];
        load([directoryname '\' filename]);
dpr2014  = DPOL.dp_ratio;
temp2014 = DPOL.temperature;
pres2014 = DPOL.pressure;
lat2014  = [DPOL.latitude];
lon2014  = [DPOL.longitude];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2018  = DPOL.dp_ratio;
temp2018 = DPOL.temperature;
pres2018 = DPOL.pressure;
lat2018  = [DPOL.latitude];
lon2018  = [DPOL.longitude];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2019  = DPOL.dp_ratio;
temp2019 = DPOL.temperature;
pres2019 = DPOL.pressure;
lat2019  = [DPOL.latitude];
lon2019  = [DPOL.longitude];

%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2020  = DPOL.dp_ratio;
temp2020 = DPOL.temperature;
pres2020 = DPOL.pressure;
lat2020  = [DPOL.latitude];
lon2020  = [DPOL.longitude];
%% to load data of year 2020
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2021  = DPOL.dp_ratio;
temp2021 = DPOL.temperature;
pres2021 = DPOL.pressure;
lat2021  = [DPOL.latitude];
lon2021  = [DPOL.longitude];

%% to load the data of SECOND month of season
m2 = str2num(mm) + 1;
mm2 = num2str(mod(m2,12),'%02d');
%% to load data of year 2014
yyyy = '2014';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);    
dpr2014  = [dpr2014; DPOL.dp_ratio];
temp2014 = [temp2014; DPOL.temperature];
pres2014 = [pres2014; DPOL.pressure];
lat2014  = [lat2014; DPOL.latitude];
lon2014  = [lon2014; DPOL.longitude];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);    
% extinc2018  = [extinc2018; DPOL.extinc];
% totbsc2018  = [totbsc2018; DPOL.total_bsc];
dpr2018  = [dpr2018; DPOL.dp_ratio];
temp2018 = [temp2018; DPOL.temperature];
pres2018 = [pres2018; DPOL.pressure];
lat2018  = [lat2018; DPOL.latitude];
lon2018  = [lon2018; DPOL.longitude];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
% extinc2019  = [extinc2019; DPOL.extinc];
% totbsc2019  = [totbsc2019; DPOL.total_bsc];
dpr2019  = [dpr2019; DPOL.dp_ratio];
temp2019 = [temp2019; DPOL.temperature];
pres2019 = [pres2019; DPOL.pressure];
lat2019  = [lat2019; DPOL.latitude];
lon2019  = [lon2019; DPOL.longitude];
%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
% extinc2020  = [extinc2020; DPOL.extinc];
% totbsc2020  = [totbsc2020; DPOL.total_bsc];
dpr2020  = [dpr2020; DPOL.dp_ratio];
temp2020 = [temp2020; DPOL.temperature];
pres2020 = [pres2020; DPOL.pressure];
lat2020  = [lat2020; DPOL.latitude];
lon2020  = [lon2020; DPOL.longitude];
%% to load data of year 2021
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
% extinc2021  = [extinc2021; DPOL.extinc];
% totbsc2021  = [totbsc2021; DPOL.total_bsc];
dpr2021  = [dpr2021; DPOL.dp_ratio];
temp2021 = [temp2021; DPOL.temperature];
pres2021 = [pres2021; DPOL.pressure];
lat2021  = [lat2021; DPOL.latitude];
lon2021  = [lon2021; DPOL.longitude];

%% to load the data of THIRD month of season
m3 = str2num(mm) + 2;
mm3 = num2str(mod(m3,12),'%02d');
%% to load data of year 2014
yyyy = '2014';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]); 
dpr2014  = [dpr2014; DPOL.dp_ratio];
temp2014 = [temp2014; DPOL.temperature];
pres2014 = [pres2014; DPOL.pressure];
lat2014  = [lat2014; DPOL.latitude];
lon2014  = [lon2014; DPOL.longitude];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);    
% extinc2018  = [extinc2018; DPOL.extinc];
% totbsc2018  = [totbsc2018; DPOL.total_bsc];
dpr2018  = [dpr2018; DPOL.dp_ratio];
temp2018 = [temp2018; DPOL.temperature];
pres2018 = [pres2018; DPOL.pressure];
lat2018  = [lat2018; DPOL.latitude];
lon2018  = [lon2018; DPOL.longitude];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
% extinc2019  = [extinc2019; DPOL.extinc];
% totbsc2019  = [totbsc2019; DPOL.total_bsc];
dpr2019  = [dpr2019; DPOL.dp_ratio];
temp2019 = [temp2019; DPOL.temperature];
pres2019 = [pres2019; DPOL.pressure];
lat2019  = [lat2019; DPOL.latitude];
lon2019  = [lon2019; DPOL.longitude];
%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
% extinc2020  = [extinc2020; DPOL.extinc];
% totbsc2020  = [totbsc2020; DPOL.total_bsc];
dpr2020  = [dpr2020; DPOL.dp_ratio];
temp2020 = [temp2020; DPOL.temperature];
pres2020 = [pres2020; DPOL.pressure];
lat2020  = [lat2020; DPOL.latitude];
lon2020  = [lon2020; DPOL.longitude];
%% to load data of year 2021
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
% extinc2021  = [extinc2021; DPOL.extinc];
% totbsc2021  = [totbsc2021; DPOL.total_bsc];
dpr2021  = [dpr2021; DPOL.dp_ratio];
temp2021 = [temp2021; DPOL.temperature];
pres2021 = [pres2021; DPOL.pressure];
lat2021  = [lat2021; DPOL.latitude];
lon2021  = [lon2021; DPOL.longitude];
%% to remove the points with cidepol < 0.1 and cidepol > 0.8
dprmin = 0.05;
dprmax = 0.9;
for jh = 1:545    
    jnan = find(dpr2014(:,jh) < dprmin | dpr2014(:,jh) > dprmax);
    dpr2014(jnan,jh) = NaN;
    jnan = find(dpr2018(:,jh) < dprmin | dpr2018(:,jh) > dprmax);
    dpr2018(jnan,jh) = NaN;
    jnan = find(dpr2019(:,jh) < dprmin | dpr2019(:,jh) > dprmax);
    dpr2019(jnan,jh) = NaN;
    
    jnan = find(dpr2020(:,jh) < dprmin | dpr2020(:,jh) > dprmax);
    dpr2020(jnan,jh) = NaN;
    jnan = find(dpr2021(:,jh) < dprmin | dpr2021(:,jh) > dprmax);
    dpr2021(jnan,jh) = NaN;
end
%% height
height = DPOL.height;
%% to remove data not within the altitudes of 6-13 km
hmin = 6;
hmax = 12;
jhc = find(height > hmin & height < hmax);
jmin = jhc(1) - 1; %% 183 - 4.99;      216 - 5.98
jmax = jhc(end) + 1; %% 405 - 15.1 km    371 - 13.06
dpr2014(:,1:jmin) = NaN; dpr2014(:,jmax:end) = NaN;
dpr2018(:,1:jmin) = NaN; dpr2018(:,jmax:end) = NaN;
dpr2019(:,1:jmin) = NaN; dpr2019(:,jmax:end) = NaN;
dpr2020(:,1:jmin) = NaN; dpr2020(:,jmax:end) = NaN;
dpr2021(:,1:jmin) = NaN; dpr2021(:,jmax:end) = NaN;
%% to remove data with temperature higher than -38 deg
dpr2014(temp2014 > -38) = NaN;
dpr2018(temp2018 > -38) = NaN;
dpr2019(temp2019 > -38) = NaN;
dpr2020(temp2020 > -38) = NaN;
dpr2021(temp2021 > -38) = NaN;
%% to sort data for ML and HL separated at latitude of 60 deg
hl2014 = find(lat2014 >= 60);
ml2014 = find(lat2014 < 60);
    dpr2014_hl = dpr2014(hl2014,:);
    dpr2014_ml = dpr2014(ml2014,:);
    temp2014_hl = temp2014(hl2014,:);
    temp2014_ml = temp2014(ml2014,:);
    pres2014_hl = pres2014(hl2014,:);
    pres2014_ml = pres2014(ml2014,:);
hl2018 = find(lat2018 >= 60);
ml2018 = find(lat2018 < 60);
    dpr2018_hl = dpr2018(hl2018,:);
    dpr2018_ml = dpr2018(ml2018,:);
    temp2018_hl = temp2018(hl2018,:);
    temp2018_ml = temp2018(ml2018,:);
    pres2018_hl = pres2018(hl2018,:);
    pres2018_ml = pres2018(ml2018,:);
hl2019 = find(lat2019 >= 60);
ml2019 = find(lat2019 < 60);
    dpr2019_hl = dpr2019(hl2019,:);
    dpr2019_ml = dpr2019(ml2019,:);
    temp2019_hl = temp2019(hl2019,:);
    temp2019_ml = temp2019(ml2019,:);
    pres2019_hl = pres2019(hl2019,:);
    pres2019_ml = pres2019(ml2019,:);
hl2020 = find(lat2020 >= 60);
ml2020 = find(lat2020 < 60);
    dpr2020_hl = dpr2020(hl2020,:);
    dpr2020_ml = dpr2020(ml2020,:);
    temp2020_hl = temp2020(hl2020,:);
    temp2020_ml = temp2020(ml2020,:);
    pres2020_hl = pres2020(hl2020,:);
    pres2020_ml = pres2020(ml2020,:);
hl2021 = find(lat2021 >= 60);
ml2021 = find(lat2021 < 60);
    dpr2021_hl = dpr2021(hl2021,:);
    dpr2021_ml = dpr2021(ml2021,:);
    temp2021_hl = temp2021(hl2021,:);
    temp2021_ml = temp2021(ml2021,:);
    pres2021_hl = pres2021(hl2021,:);
    pres2021_ml = pres2021(ml2021,:);
% %% to calculate the correlation between depol and temperature
%% 2014 HL
dpr_res  = reshape(dpr2014_hl,1,[]);
temp_res = reshape(temp2014_hl,1,[]);
knnan = find(~isnan(dpr_res));
dpr_resrev  = dpr_res(knnan);
temp_resrev = temp_res(knnan);

tempsc = -80:1:-38;
p_dprtemp = polyfit(temp_resrev,dpr_resrev,1);
fit_dprtemp2014_hl = polyval(p_dprtemp,tempsc);
[ntemp2014_hl,xtemp2014_hl,ytemp2014_hl] = hist3([dpr_resrev;temp_resrev]',100);
ntemp2014_hl(ntemp2014_hl < 5) = NaN;
%% 2014 ML
dpr_res  = reshape(dpr2014_ml,1,[]);
temp_res = reshape(temp2014_ml,1,[]);
knnan = find(~isnan(dpr_res));
dpr_resrev  = dpr_res(knnan);
temp_resrev = temp_res(knnan);

tempsc = -80:1:-38;
p_dprtemp = polyfit(temp_resrev,dpr_resrev,1);
fit_dprtemp2014_ml = polyval(p_dprtemp,tempsc);
[ntemp2014_ml,xtemp2014_ml,ytemp2014_ml] = hist3([dpr_resrev;temp_resrev]',100);
ntemp2014_ml(ntemp2014_ml < 5) = NaN;
%% 2018 HL
dpr_res  = reshape(dpr2018_hl,1,[]);
temp_res = reshape(temp2018_hl,1,[]);
knnan = find(~isnan(dpr_res));
dpr_resrev  = dpr_res(knnan);
temp_resrev = temp_res(knnan);

tempsc = -80:1:-38;
p_dprtemp = polyfit(temp_resrev,dpr_resrev,1);
fit_dprtemp2018_hl = polyval(p_dprtemp,tempsc);
[ntemp2018_hl,xtemp2018_hl,ytemp2018_hl] = hist3([dpr_resrev;temp_resrev]',100);
ntemp2018_hl(ntemp2018_hl < 5) = NaN;
%% 2018 ML
dpr_res  = reshape(dpr2018_ml,1,[]);
temp_res = reshape(temp2018_ml,1,[]);
knnan = find(~isnan(dpr_res));
dpr_resrev  = dpr_res(knnan);
temp_resrev = temp_res(knnan);

tempsc = -80:1:-38;
p_dprtemp = polyfit(temp_resrev,dpr_resrev,1);
fit_dprtemp2018_ml = polyval(p_dprtemp,tempsc);
[ntemp2018_ml,xtemp2018_ml,ytemp2018_ml] = hist3([dpr_resrev;temp_resrev]',100);
ntemp2018_ml(ntemp2018_ml < 5) = NaN;
%% 2019 HL
dpr_res  = reshape(dpr2019_hl,1,[]);
temp_res = reshape(temp2019_hl,1,[]);
knnan = find(~isnan(dpr_res));
dpr_resrev  = dpr_res(knnan);
temp_resrev = temp_res(knnan);

tempsc = -80:1:-38;
p_dprtemp = polyfit(temp_resrev,dpr_resrev,1);
fit_dprtemp2019_hl = polyval(p_dprtemp,tempsc);
[ntemp2019_hl,xtemp2019_hl,ytemp2019_hl] = hist3([dpr_resrev;temp_resrev]',100);
ntemp2019_hl(ntemp2019_hl < 5) = NaN;
%% 2019 ML
dpr_res  = reshape(dpr2019_ml,1,[]);
temp_res = reshape(temp2019_ml,1,[]);
knnan = find(~isnan(dpr_res));
dpr_resrev  = dpr_res(knnan);
temp_resrev = temp_res(knnan);

tempsc = -80:1:-38;
p_dprtemp = polyfit(temp_resrev,dpr_resrev,1);
fit_dprtemp2019_ml = polyval(p_dprtemp,tempsc);
[ntemp2019_ml,xtemp2019_ml,ytemp2019_ml] = hist3([dpr_resrev;temp_resrev]',100);
ntemp2019_ml(ntemp2019_ml < 5) = NaN;
%% 2020 HL
dpr_res  = reshape(dpr2020_hl,1,[]);
temp_res = reshape(temp2020_hl,1,[]);
knnan = find(~isnan(dpr_res));
dpr_resrev  = dpr_res(knnan);
temp_resrev = temp_res(knnan);

tempsc = -80:1:-38;
p_dprtemp = polyfit(temp_resrev,dpr_resrev,1);
fit_dprtemp2020_hl = polyval(p_dprtemp,tempsc);
[ntemp2020_hl,xtemp2020_hl,ytemp2020_hl] = hist3([dpr_resrev;temp_resrev]',100);
ntemp2020_hl(ntemp2020_hl < 5) = NaN;
%% 2020 ML
dpr_res  = reshape(dpr2020_ml,1,[]);
temp_res = reshape(temp2020_ml,1,[]);
knnan = find(~isnan(dpr_res));
dpr_resrev  = dpr_res(knnan);
temp_resrev = temp_res(knnan);

tempsc = -80:1:-38;
p_dprtemp = polyfit(temp_resrev,dpr_resrev,1);
fit_dprtemp2020_ml = polyval(p_dprtemp,tempsc);
[ntemp2020_ml,xtemp2020_ml,ytemp2020_ml] = hist3([dpr_resrev;temp_resrev]',100);
ntemp2020_ml(ntemp2020_ml < 5) = NaN;
%% 2021 HL
dpr_res  = reshape(dpr2021_hl,1,[]);
temp_res = reshape(temp2021_hl,1,[]);
knnan = find(~isnan(dpr_res));
dpr_resrev  = dpr_res(knnan);
temp_resrev = temp_res(knnan);

tempsc = -80:1:-38;
p_dprtemp = polyfit(temp_resrev,dpr_resrev,1);
fit_dprtemp2021_hl = polyval(p_dprtemp,tempsc);
[ntemp2021_hl,xtemp2021_hl,ytemp2021_hl] = hist3([dpr_resrev;temp_resrev]',100);
ntemp2021_hl(ntemp2021_hl < 5) = NaN;
%% 2021 ML
dpr_res  = reshape(dpr2021_ml,1,[]);
temp_res = reshape(temp2021_ml,1,[]);
knnan = find(~isnan(dpr_res));
dpr_resrev  = dpr_res(knnan);
temp_resrev = temp_res(knnan);

tempsc = -80:1:-38;
p_dprtemp = polyfit(temp_resrev,dpr_resrev,1);
fit_dprtemp2021_ml = polyval(p_dprtemp,tempsc);
[ntemp2021_ml,xtemp2021_ml,ytemp2021_ml] = hist3([dpr_resrev;temp_resrev]',100);
ntemp2021_ml(ntemp2021_ml < 5) = NaN;
%% to calculate the correlation between depol and pressure
%% 2014 HL
dpr_res  = reshape(dpr2014_hl,1,[]);
pres_res = reshape((pres2014_hl),1,[]);
dpnan = find(~isnan(dpr_res));
dpr_resrev  = dpr_res(dpnan);
pres_resrev = pres_res(dpnan);

% pressc = 0:1:1000;
% p_dprpres = polyfit(pres_resrev,dpr_resrev,1);
% fit_dprpres2014_hl = polyval(p_dprpres,pressc);
% [npres2014_hl,xpres2014_hl,ypres2014_hl] = hist3([dpr_resrev;pres_resrev]',80);
% npres2014_hl(npres2014_hl < 5) = NaN;
% 
% psc_def = 0:5:1000; %% default scale of pressure
% [dprvsp_prc2014_hl cior2014_hl] = Depolsortvsp(dpr_res,pres_res,psc_def);
% %% 2014 ML
% dpr_res  = reshape(dpr2014_ml,1,[]);
% pres_res = reshape((pres2014_ml),1,[]);
% dpnan = find(~isnan(dpr_res));
% dpr_resrev  = dpr_res(dpnan);
% pres_resrev = pres_res(dpnan);
% 
% pressc = 0:1:1000;
% p_dprpres = polyfit(pres_resrev,dpr_resrev,1);
% fit_dprpres2014_ml = polyval(p_dprpres,pressc);
% [npres2014_ml,xpres2014_ml,ypres2014_ml] = hist3([dpr_resrev;pres_resrev]',80);
% npres2014_ml(npres2014_ml < 5) = NaN;
% 
% [dprvsp_prc2014_ml cior2014_ml] = Depolsortvsp(dpr_res,pres_res,psc_def);
% %% 2018 HL
% dpr_res  = reshape(dpr2018_hl,1,[]);
% pres_res = reshape((pres2018_hl),1,[]);
% dpnan = find(~isnan(dpr_res));
% dpr_resrev  = dpr_res(dpnan);
% pres_resrev = pres_res(dpnan);
% 
% pressc = 0:1:1000;
% p_dprpres = polyfit(pres_resrev,dpr_resrev,1);
% fit_dprpres2018_hl = polyval(p_dprpres,pressc);
% [npres2018_hl,xpres2018_hl,ypres2018_hl] = hist3([dpr_resrev;pres_resrev]',80);
% npres2018_hl(npres2018_hl < 5) = NaN;
% 
% psc_def = 0:5:1000; %% default scale of pressure
% [dprvsp_prc2018_hl cior2018_hl] = Depolsortvsp(dpr_res,pres_res,psc_def);
% %% 2018 ML
% dpr_res  = reshape(dpr2018_ml,1,[]);
% pres_res = reshape((pres2018_ml),1,[]);
% dpnan = find(~isnan(dpr_res));
% dpr_resrev  = dpr_res(dpnan);
% pres_resrev = pres_res(dpnan);
% 
% pressc = 0:1:1000;
% p_dprpres = polyfit(pres_resrev,dpr_resrev,1);
% fit_dprpres2018_ml = polyval(p_dprpres,pressc);
% [npres2018_ml,xpres2018_ml,ypres2018_ml] = hist3([dpr_resrev;pres_resrev]',80);
% npres2018_ml(npres2018_ml < 5) = NaN;
% 
% [dprvsp_prc2018_ml cior2018_ml] = Depolsortvsp(dpr_res,pres_res,psc_def);
% %% 2019 HL
% dpr_res  = reshape(dpr2019_hl,1,[]);
% pres_res = reshape((pres2019_hl),1,[]);
% dpnan = find(~isnan(dpr_res));
% dpr_resrev  = dpr_res(dpnan);
% pres_resrev = pres_res(dpnan);
% 
% pressc = 0:1:1000;
% p_dprpres = polyfit(pres_resrev,dpr_resrev,1);
% fit_dprpres2019_hl = polyval(p_dprpres,pressc);
% [npres2019_hl,xpres2019_hl,ypres2019_hl] = hist3([dpr_resrev;pres_resrev]',80);
% npres2019_hl(npres2019_hl < 5) = NaN;
% 
% [dprvsp_prc2019_hl cior2019_hl] = Depolsortvsp(dpr_res,pres_res,psc_def);
% %% 2019 ML
% dpr_res  = reshape(dpr2019_ml,1,[]);
% pres_res = reshape((pres2019_ml),1,[]);
% dpnan = find(~isnan(dpr_res));
% dpr_resrev  = dpr_res(dpnan);
% pres_resrev = pres_res(dpnan);
% 
% pressc = 0:1:1000;
% p_dprpres = polyfit(pres_resrev,dpr_resrev,1);
% fit_dprpres2019_ml = polyval(p_dprpres,pressc);
% [npres2019_ml,xpres2019_ml,ypres2019_ml] = hist3([dpr_resrev;pres_resrev]',80);
% npres2019_ml(npres2019_ml < 5) = NaN;
% 
% [dprvsp_prc2019_ml cior2019_ml] = Depolsortvsp(dpr_res,pres_res,psc_def);
% %% 2020 HL
% dpr_res  = reshape(dpr2020_hl,1,[]);
% pres_res = reshape((pres2020_hl),1,[]);
% dpnan = find(~isnan(dpr_res));
% dpr_resrev  = dpr_res(dpnan);
% pres_resrev = pres_res(dpnan);
% 
% pressc = 0:1:1000;
% p_dprpres = polyfit(pres_resrev,dpr_resrev,1);
% fit_dprpres2020_hl = polyval(p_dprpres,pressc);
% [npres2020_hl,xpres2020_hl,ypres2020_hl] = hist3([dpr_resrev;pres_resrev]',80);
% npres2020_hl(npres2020_hl < 5) = NaN;
% 
% [dprvsp_prc2020_hl cior2020_hl] = Depolsortvsp(dpr_res,pres_res,psc_def);
% %% 2020 ML
% dpr_res  = reshape(dpr2020_ml,1,[]);
% pres_res = reshape((pres2020_ml),1,[]);
% dpnan = find(~isnan(dpr_res));
% dpr_resrev  = dpr_res(dpnan);
% pres_resrev = pres_res(dpnan);
% 
% pressc = 0:1:1000;
% p_dprpres = polyfit(pres_resrev,dpr_resrev,1);
% fit_dprpres2020_ml = polyval(p_dprpres,pressc);
% [npres2020_ml,xpres2020_ml,ypres2020_ml] = hist3([dpr_resrev;pres_resrev]',80);
% npres2020_ml(npres2020_ml < 5) = NaN;
% 
% [dprvsp_prc2020_ml cior2020_ml] = Depolsortvsp(dpr_res,pres_res,psc_def);
% %% 2021 HL
% dpr_res  = reshape(dpr2021_hl,1,[]);
% pres_res = reshape((pres2021_hl),1,[]);
% dpnan = find(~isnan(dpr_res));
% dpr_resrev  = dpr_res(dpnan);
% pres_resrev = pres_res(dpnan);
% 
% pressc = 0:1:1000;
% p_dprpres = polyfit(pres_resrev,dpr_resrev,1);
% fit_dprpres2021_hl = polyval(p_dprpres,pressc);
% [npres2021_hl,xpres2021_hl,ypres2021_hl] = hist3([dpr_resrev;pres_resrev]',80);
% npres2021_hl(npres2021_hl < 5) = NaN;
% 
% [dprvsp_prc2021_hl cior2021_hl] = Depolsortvsp(dpr_res,pres_res,psc_def);
% %% 2021 ML
% dpr_res  = reshape(dpr2021_ml,1,[]);
% pres_res = reshape((pres2021_ml),1,[]);
% dpnan = find(~isnan(dpr_res));
% dpr_resrev  = dpr_res(dpnan);
% pres_resrev = pres_res(dpnan);
% 
% pressc = 0:1:1000;
% p_dprpres = polyfit(pres_resrev,dpr_resrev,1);
% fit_dprpres2021_ml = polyval(p_dprpres,pressc);
% [npres2021_ml,xpres2021_ml,ypres2021_ml] = hist3([dpr_resrev;pres_resrev]',80);
% npres2021_ml(npres2021_ml < 5) = NaN;
% 
% [dprvsp_prc2021_ml cior2021_ml] = Depolsortvsp(dpr_res,pres_res,psc_def);
%%
clear DPOL;
clear dpr2014 dpr2018 dpr2019 dpr2020 dpr2021 ;
clear pres2014 pres2018 pres2019 pres2020 pres2021 ;
clear temp2014 temp2018 temp2019 temp2020 temp2021 ;

% pres2014_hl(isnan(dpr2014_hl)) = NaN;
% pres2018_hl(isnan(dpr2018_hl)) = NaN;
% pres2019_hl(isnan(dpr2019_hl)) = NaN;
% pres2020_hl(isnan(dpr2020_hl)) = NaN;
% pres2021_hl(isnan(dpr2021_hl)) = NaN;
% pres_5yr_hl = [pres2014_hl; pres2018_hl; pres2019_hl; pres2020_hl; pres2021_hl; ];
% 
% pres2014_ml(isnan(dpr2014_ml)) = NaN;
% pres2018_ml(isnan(dpr2018_ml)) = NaN;
% pres2019_ml(isnan(dpr2019_ml)) = NaN;
% pres2020_ml(isnan(dpr2020_ml)) = NaN;
% pres2021_ml(isnan(dpr2021_ml)) = NaN;
% pres_5yr_ml = [pres2014_ml; pres2018_ml; pres2019_ml; pres2020_ml; pres2021_ml; ];

temp2014_hl(isnan(dpr2014_hl)) = NaN;
temp2018_hl(isnan(dpr2018_hl)) = NaN;
temp2019_hl(isnan(dpr2019_hl)) = NaN;
temp2020_hl(isnan(dpr2020_hl)) = NaN;
temp2021_hl(isnan(dpr2021_hl)) = NaN;
temp_5yr_hl = [temp2014_hl; temp2018_hl; temp2019_hl; temp2020_hl; temp2021_hl; ];

temp2014_ml(isnan(dpr2014_ml)) = NaN;
temp2018_ml(isnan(dpr2018_ml)) = NaN;
temp2019_ml(isnan(dpr2019_ml)) = NaN;
temp2020_ml(isnan(dpr2020_ml)) = NaN;
temp2021_ml(isnan(dpr2021_ml)) = NaN;
temp_5yr_ml = [temp2014_ml; temp2018_ml; temp2019_ml; temp2020_ml; temp2021_ml; ];
%% to plot
fz = 12;
%%

scalt = -100:1:-30; 
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fyr = figure(4022)
set(fyr,'units','inch','position',[.3,.7,9,6]);
subplot(2,3,1)
hold on
[c f] = hist(reshape(temp2014_hl,1,[]),scalt);
bar(f,c/sum(c)*100,0.8,'facecolor',[0.5 0.5 0.5],'edgecolor','none');
[c f] = hist(reshape(temp2014_ml,1,[]),scalt);
bar(f,c/sum(c)*100,0.4,'k','edgecolor','none')
set(gca,'ylim',[0 10],'ytick',[0:1:20],'FontSize',fz);
 set(gca,'xlim',[-70 -35],'xtick',[-70:10:-40 -35],'FontSize',fz);
set(gca,'tickdir','out');
set(gca,'xminortick','on');
% set(gca,'yminortick','on')
ylabel('Probability [%]','FontWeight','bold','FontSize',15);
leg = legend('HL','ML');
rect = [0.27, 0.820, .05, .05];
set(leg, 'Position', rect);
text(-69,9.3,['2014'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
text(-69,8.0,['\color[rgb]{0.5 0.5 0.5}Med: ' num2str(nanmedian(reshape(temp2014_hl,1,[])),'%0.1f')],'FontSize',fz);
text(-69,7.1,['Med: ' num2str(nanmedian(reshape(temp2014_ml,1,[])),'%0.1f')],'FontSize',fz);
if fileext(2) == 'D' & fileext(3) == 'N'
    title(['DN ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)],'FontWeight','bold','FontSize',15);
elseif fileext(3) == 'D'
    title(['ZD ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)],'FontWeight','bold','FontSize',15);
elseif fileext(3) == 'N'
    title(['DN ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)],'FontWeight','bold','FontSize',15);
end
hold off

subplot(2,3,2)
hold on
[c f] = hist(reshape(temp2018_hl,1,[]),scalt);
bar(f,c/sum(c)*100,0.8,'facecolor',[0.5 0.5 0.5],'edgecolor','none');
[c f] = hist(reshape(temp2018_ml,1,[]),scalt);
bar(f,c/sum(c)*100,0.4,'k','edgecolor','none')
set(gca,'ylim',[0 10],'ytick',[0:1:20],'FontSize',fz);
 set(gca,'xlim',[-70 -35],'xtick',[-70:10:-40 -35],'FontSize',fz);
set(gca,'tickdir','out');
set(gca,'xminortick','on');
% set(gca,'yminortick','on')
text(-69,9.3,['2018'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
text(-69,8.0,['\color[rgb]{0.5 0.5 0.5}Med: ' num2str(nanmedian(reshape(temp2018_hl,1,[])),'%0.1f')],'FontSize',fz);
text(-69,7.1,['Med: ' num2str(nanmedian(reshape(temp2018_ml,1,[])),'%0.1f')],'FontSize',fz);
% if fileext(2) == 'D' & fileext(3) == 'N'
%     title(['DN ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% elseif fileext(3) == 'D'
%     title(['ZD ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% elseif fileext(3) == 'N'
%     title(['DN ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% end
hold off
subplot(2,3,3)
hold on
[c f] = hist(reshape(temp2019_hl,1,[]),scalt);
bar(f,c/sum(c)*100,0.8,'facecolor',[0.5 0.5 0.5],'edgecolor','none');
[c f] = hist(reshape(temp2019_ml,1,[]),scalt);
bar(f,c/sum(c)*100,0.4,'k','edgecolor','none')
set(gca,'ylim',[0 10],'ytick',[0:1:20],'FontSize',fz);
 set(gca,'xlim',[-70 -35],'xtick',[-70:10:-40 -35],'FontSize',fz);
set(gca,'tickdir','out');
set(gca,'xminortick','on');
% set(gca,'yminortick','on')
text(-69,9.3,['2019'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
text(-69,8.0,['\color[rgb]{0.5 0.5 0.5}Med: ' num2str(nanmedian(reshape(temp2019_hl,1,[])),'%0.1f')],'FontSize',fz);
text(-69,7.1,['Med: ' num2str(nanmedian(reshape(temp2019_ml,1,[])),'%0.1f')],'FontSize',fz);
% if fileext(2) == 'D' & fileext(3) == 'N'
%     title(['DN ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% elseif fileext(3) == 'D'
%     title(['ZD ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% elseif fileext(3) == 'N'
%     title(['DN ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% end
hold off
subplot(2,3,4)
hold on
[c f] = hist(reshape(temp2020_hl,1,[]),scalt);
bar(f,c/sum(c)*100,0.8,'facecolor',[0.5 0.5 0.5],'edgecolor','none');
[c f] = hist(reshape(temp2020_ml,1,[]),scalt);
bar(f,c/sum(c)*100,0.4,'k','edgecolor','none')
set(gca,'ylim',[0 10],'ytick',[0:1:20],'FontSize',fz);
 set(gca,'xlim',[-70 -35],'xtick',[-70:10:-40 -35],'FontSize',fz);
set(gca,'tickdir','out');
set(gca,'xminortick','on');
% set(gca,'yminortick','on')
xlabel('Temp in cloud [\circC]','FontWeight','bold','FontSize',fz);
ylabel('Probability [%]','FontWeight','bold','FontSize',15);
text(-69,9.3,['2020'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
text(-69,8.0,['\color[rgb]{0.5 0.5 0.5}Med: ' num2str(nanmedian(reshape(temp2020_hl,1,[])),'%0.1f')],'FontSize',fz);
text(-69,7.1,['Med: ' num2str(nanmedian(reshape(temp2020_ml,1,[])),'%0.1f')],'FontSize',fz);
% if fileext(2) == 'D' & fileext(3) == 'N'
%     title(['DN ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% elseif fileext(3) == 'D'
%     title(['ZD ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% elseif fileext(3) == 'N'
%     title(['DN ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% end
hold off
subplot(2,3,5)
hold on
[c f] = hist(reshape(temp2021_hl,1,[]),scalt);
bar(f,c/sum(c)*100,0.8,'facecolor',[0.5 0.5 0.5],'edgecolor','none');
[c f] = hist(reshape(temp2021_ml,1,[]),scalt);
bar(f,c/sum(c)*100,0.4,'k','edgecolor','none')
set(gca,'ylim',[0 10],'ytick',[0:1:20],'FontSize',fz);
 set(gca,'xlim',[-70 -35],'xtick',[-70:10:-40 -35],'FontSize',fz);
set(gca,'tickdir','out');
set(gca,'xminortick','on');
% set(gca,'yminortick','on')
xlabel('Temp in cloud [\circC]','FontWeight','bold','FontSize',fz);
text(-69,9.3,['2021'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
text(-69,8.0,['\color[rgb]{0.5 0.5 0.5}Med: ' num2str(nanmedian(reshape(temp2021_hl,1,[])),'%0.1f')],'FontSize',fz);
text(-69,7.1,['Med: ' num2str(nanmedian(reshape(temp2021_ml,1,[])),'%0.1f')],'FontSize',fz);
% if fileext(2) == 'D' & fileext(3) == 'N'
%     title(['DN ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% elseif fileext(3) == 'D'
%     title(['ZD ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% elseif fileext(3) == 'N'
%     title(['DN ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% end
hold off
subplot(2,3,6)
hold on
[c f] = hist(reshape(temp_5yr_hl,1,[]),scalt);
bar(f,c/sum(c)*100,0.8,'facecolor',[0.5 0.5 0.5],'edgecolor','none');
[c f] = hist(reshape(temp_5yr_ml,1,[]),scalt);
bar(f,c/sum(c)*100,0.4,'k','edgecolor','none')
set(gca,'ylim',[0 10],'ytick',[0:1:20],'FontSize',fz);
 set(gca,'xlim',[-70 -35],'xtick',[-70:10:-40 -35],'FontSize',fz);
set(gca,'tickdir','out');
set(gca,'xminortick','on');
% set(gca,'yminortick','on')
xlabel('Temp in cloud [\circC]','FontWeight','bold','FontSize',fz);
text(-69,9.3,['5 yrs'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
text(-69,8.0,['\color[rgb]{0.5 0.5 0.5}Med: ' num2str(nanmedian(reshape(temp_5yr_hl,1,[])),'%0.1f')],'FontSize',fz);
text(-69,7.1,['Med: ' num2str(nanmedian(reshape(temp_5yr_ml,1,[])),'%0.1f')],'FontSize',fz);
% if fileext(2) == 'D' & fileext(3) == 'N'
%     title(['DN ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% elseif fileext(3) == 'D'
%     title(['ZD ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% elseif fileext(3) == 'N'
%     title(['DN ' num2str(hmin) '-' num2str(hmax) 'km, ' mm_str(1:3)]);
% end
hold off

print('-dpng','-painters',['hist_tempInc_HLvsML_H' num2str(hmin) '-' num2str(hmax) '_' mm_str fileext(1:10) '_5yrs_2.png']);
print(fyr, ['hist_tempInc_HLvsML_H' num2str(hmin) '-' num2str(hmax) '_' mm_str fileext(1:10) '_5yrs_2'], '-dpdf')

figname = ['hist_tempInc_HLvsML_H' num2str(hmin) '-' num2str(hmax) '_' mm_str fileext(1:10) '_5yrs_2'];
saveas(gcf,figname,'fig');
%%%%%%