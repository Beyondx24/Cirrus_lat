%% this routine is to plot the right panel of figure4 - boxplot of extinction at ML and HL in years of 2014 and 2018-2021
%% tested under the MATLAB 2010B
clear all; clc; format long; close all
directoryname = pwd;  %% the current folder, where the MATLAB data are stored
%%
fileext    = '_DN_Europe.mat'
% fileext    = '_ZN_Europe.mat';
%% to load the data of FIRST month of season
mm = '03';          % to change the number (03, 06, 09, 12) for different season 
mm_str = 'MAM';     % to change the season (MAM, JJA, SON, DJF)

drtar = 'dp_ratio'; % drtar - depol of target
%% to load data of year 2014
yyyy = '2014';
    filename = ['DPOL_extinc_' yyyy '-' mm fileext];
        load([directoryname '\' filename]);
    dpr2014  = DPOL.dp_ratio;
    temp2014 = DPOL.temperature;
    lat2014  = [DPOL.latitude];
    lon2014  = [DPOL.longitude];
    extinc2014  = DPOL.extinc;
%% to load data of year 2018
yyyy = '2018';
if str2num(mm) > 10
    dpr2018  = [];
    temp2018 = [];
    lat2018  = [];
    lon2018  = [];
    extinc2018  = [];
else
    filename = ['DPOL_extinc_' yyyy '-' mm fileext];
        load([directoryname '\' filename]);
    dpr2018  = DPOL.dp_ratio;
    temp2018 = DPOL.temperature;
    lat2018  = [DPOL.latitude];
    lon2018  = [DPOL.longitude];
    extinc2018  = DPOL.extinc;
end
%% to load data of year 2019
yyyy = '2019';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2019  = DPOL.dp_ratio;
temp2019 = DPOL.temperature;
lat2019  = [DPOL.latitude];
lon2019  = [DPOL.longitude];
extinc2019  = DPOL.extinc;
%% to load data of year 2020
yyyy = '2020';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2020  = DPOL.dp_ratio;
temp2020 = DPOL.temperature;
lat2020  = [DPOL.latitude];
lon2020  = [DPOL.longitude];
extinc2020  = DPOL.extinc;
%% to load data of year 2020
yyyy = '2021';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2021  = DPOL.dp_ratio;
temp2021 = DPOL.temperature;
lat2021  = [DPOL.latitude];
lon2021  = [DPOL.longitude];
extinc2021  = DPOL.extinc;
%% to load the data of SECOND month of season
m2 = str2num(mm) + 1;
mm2 = num2str(mod(m2,12),'%02d');
%% to load data of year 2014
yyyy = '2014';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);    
dpr2014  = [dpr2014; DPOL.dp_ratio];
temp2014 = [temp2014; DPOL.temperature];
lat2014  = [lat2014; DPOL.latitude];
lon2014  = [lon2014; DPOL.longitude];
extinc2014  = [extinc2014; DPOL.extinc];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);    
dpr2018  = [dpr2018; DPOL.dp_ratio];
temp2018 = [temp2018; DPOL.temperature];
lat2018  = [lat2018; DPOL.latitude];
lon2018  = [lon2018; DPOL.longitude];
extinc2018  = [extinc2018; DPOL.extinc];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2019  = [dpr2019; DPOL.dp_ratio];
temp2019 = [temp2019; DPOL.temperature];
lat2019  = [lat2019; DPOL.latitude];
lon2019  = [lon2019; DPOL.longitude];
extinc2019  = [extinc2019; DPOL.extinc];
%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2020  = [dpr2020; DPOL.dp_ratio];
temp2020 = [temp2020; DPOL.temperature];
lat2020  = [lat2020; DPOL.latitude];
lon2020  = [lon2020; DPOL.longitude];
extinc2020  = [extinc2020; DPOL.extinc];
%% to load data of year 2021
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2021  = [dpr2021; DPOL.dp_ratio];
temp2021 = [temp2021; DPOL.temperature];
lat2021  = [lat2021; DPOL.latitude];
lon2021  = [lon2021; DPOL.longitude];
extinc2021  = [extinc2021; DPOL.extinc];
%% to load the data of THIRD month of season
m3 = str2num(mm) + 2;
mm3 = num2str(mod(m3,12),'%02d');
%% to load data of year 2014
yyyy = '2014';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);    
dpr2014  = [dpr2014; DPOL.dp_ratio];
temp2014 = [temp2014; DPOL.temperature];
lat2014  = [lat2014; DPOL.latitude];
lon2014  = [lon2014; DPOL.longitude];
extinc2014  = [extinc2014; DPOL.extinc];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);    
dpr2018  = [dpr2018; DPOL.dp_ratio];
temp2018 = [temp2018; DPOL.temperature];
lat2018  = [lat2018; DPOL.latitude];
lon2018  = [lon2018; DPOL.longitude];
extinc2018  = [extinc2018; DPOL.extinc];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2019  = [dpr2019; DPOL.dp_ratio];
temp2019 = [temp2019; DPOL.temperature];
lat2019  = [lat2019; DPOL.latitude];
lon2019  = [lon2019; DPOL.longitude];
extinc2019  = [extinc2019; DPOL.extinc];
%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2020  = [dpr2020; DPOL.dp_ratio];
temp2020 = [temp2020; DPOL.temperature];
lat2020  = [lat2020; DPOL.latitude];
lon2020  = [lon2020; DPOL.longitude];
extinc2020  = [extinc2020; DPOL.extinc];
%% to load data of year 2021
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2021  = [dpr2021; DPOL.dp_ratio];
temp2021 = [temp2021; DPOL.temperature];
lat2021  = [lat2021; DPOL.latitude];
lon2021  = [lon2021; DPOL.longitude];
extinc2021  = [extinc2021; DPOL.extinc];
%% height
height = DPOL.height;
clear DPOL;
%% to remove the points with cidepol < 0.05 and cidepol > 0.85
dprmin = 0.1;
dprmax = 0.8;
for jh = 1:545    
    jnan = find(dpr2014(:,jh) < dprmin | dpr2014(:,jh) > dprmax);
    dpr2014(jnan,jh) = NaN;  
    jnan = find(dpr2018(:,jh) < dprmin | dpr2018(:,jh) > dprmax);
    dpr2018(jnan,jh) = NaN;  
    jnan = find(dpr2019(:,jh) < dprmin | dpr2019(:,jh) > dprmax);
    dpr2019(jnan,jh) = NaN;    
    jnan = find(dpr2020(:,jh) < dprmin | dpr2020(:,jh) > dprmax);
    dpr2020(jnan,jh) = NaN;
    jnan = find(dpr2021(:,jh) < dprmin | dpr2021(:,jh) > dprmax);
    dpr2021(jnan,jh) = NaN;
end
%% to remove data not within the altitudes of 6-13 km
hmin = 6;
hmax = 12;
jhc = find(height > hmin & height < hmax);
jmin = jhc(1) - 1; %% 183 - 4.99;      216 - 5.98
jmax = jhc(end) + 1; %% 405 - 15.1 km    371 - 13.06
dpr2014(:,1:jmin) = NaN; dpr2014(:,jmax:end) = NaN;
dpr2018(:,1:jmin) = NaN; dpr2018(:,jmax:end) = NaN;
dpr2019(:,1:jmin) = NaN; dpr2019(:,jmax:end) = NaN;
dpr2020(:,1:jmin) = NaN; dpr2020(:,jmax:end) = NaN;
dpr2021(:,1:jmin) = NaN; dpr2021(:,jmax:end) = NaN;
%% to remove data with temperature higher than -38 deg
tempmax = -38;
dpr2014(temp2014 > tempmax) = NaN;
dpr2018(temp2018 > tempmax) = NaN;
dpr2019(temp2019 > tempmax) = NaN;
dpr2020(temp2020 > tempmax) = NaN;
dpr2021(temp2021 > tempmax) = NaN;
temp2014(isnan(dpr2014)) = NaN;
temp2018(isnan(dpr2018)) = NaN;
temp2019(isnan(dpr2019)) = NaN;
temp2020(isnan(dpr2020)) = NaN;
temp2021(isnan(dpr2021)) = NaN;
extinc2014(isnan(dpr2014)) = NaN;
extinc2018(isnan(dpr2018)) = NaN;
extinc2019(isnan(dpr2019)) = NaN;
extinc2020(isnan(dpr2020)) = NaN;
extinc2021(isnan(dpr2021)) = NaN;
%% to sort data for ML and HL separated at latitude of 60 deg
hl2014 = find(lat2014 >= 60);
ml2014 = find(lat2014 < 60);
    temp2014_hl = temp2014(hl2014,:);
    temp2014_ml = temp2014(ml2014,:);
    extinc2014_hl = extinc2014(hl2014,:);
    extinc2014_ml = extinc2014(ml2014,:);
clear dpr2014 temp2014 extinc2014;
hl2018 = find(lat2018 >= 60);
ml2018 = find(lat2018 < 60);
    temp2018_hl = temp2018(hl2018,:);
    temp2018_ml = temp2018(ml2018,:);
    extinc2018_hl = extinc2018(hl2018,:);
    extinc2018_ml = extinc2018(ml2018,:);
clear dpr2018 temp2018 extinc2018;
hl2019 = find(lat2019 >= 60);
ml2019 = find(lat2019 < 60);
    temp2019_hl = temp2019(hl2019,:);
    temp2019_ml = temp2019(ml2019,:);
    extinc2019_hl = extinc2019(hl2019,:);
    extinc2019_ml = extinc2019(ml2019,:);
clear dpr2019 temp2019 extinc2019;
hl2020 = find(lat2020 >= 60);
ml2020 = find(lat2020 < 60);
    temp2020_hl = temp2020(hl2020,:);
    temp2020_ml = temp2020(ml2020,:);
    extinc2020_hl = extinc2020(hl2020,:);
    extinc2020_ml = extinc2020(ml2020,:);
clear dpr2020 temp2020 extinc2020 ;
hl2021 = find(lat2021 >= 60);
ml2021 = find(lat2021 < 60);
    temp2021_hl = temp2021(hl2021,:);
    temp2021_ml = temp2021(ml2021,:);
    extinc2021_hl = extinc2021(hl2021,:);
    extinc2021_ml = extinc2021(ml2021,:);    
clear dpr2021 temp2021 extinc2021;   
clear lat2014 lat2018 lat2019 lat2020 lat2021;
clear lon2014 lon2018 lon2019 lon2020 lon2021;
clear temp2014_hl     temp2018_hl     temp2019_hl     temp2020_hl     temp2021_hl;
clear temp2014_ml     temp2018_ml     temp2019_ml     temp2020_ml     temp2021_ml;
%%
extinc2014_hl_res = (reshape(extinc2014_hl,1,[]));
extinc2018_hl_res = (reshape(extinc2018_hl,1,[]));
extinc2019_hl_res = (reshape(extinc2019_hl,1,[]));
extinc2020_hl_res = (reshape(extinc2020_hl,1,[]));
extinc2021_hl_res = (reshape(extinc2021_hl,1,[]));
extinc2014_ml_res = (reshape(extinc2014_ml,1,[]));
extinc2018_ml_res = (reshape(extinc2018_ml,1,[]));
extinc2019_ml_res = (reshape(extinc2019_ml,1,[]));
extinc2020_ml_res = (reshape(extinc2020_ml,1,[]));
extinc2021_ml_res = (reshape(extinc2021_ml,1,[]));

extinc2014_hl_res(extinc2014_hl_res < 0) = NaN;
extinc2018_hl_res(extinc2018_hl_res < 0) = NaN;
extinc2019_hl_res(extinc2019_hl_res < 0) = NaN;
extinc2020_hl_res(extinc2020_hl_res < 0) = NaN;
extinc2021_hl_res(extinc2021_hl_res < 0) = NaN;
extinc2014_ml_res(extinc2014_ml_res < 0) = NaN;
extinc2018_ml_res(extinc2018_ml_res < 0) = NaN;
extinc2019_ml_res(extinc2019_ml_res < 0) = NaN;
extinc2020_ml_res(extinc2020_ml_res < 0) = NaN;
extinc2021_ml_res(extinc2021_ml_res < 0) = NaN;

extinc2014_hl_log = log10(extinc2014_hl_res);
extinc2018_hl_log = log10(extinc2018_hl_res);
extinc2019_hl_log = log10(extinc2019_hl_res);
extinc2020_hl_log = log10(extinc2020_hl_res);
extinc2021_hl_log = log10(extinc2021_hl_res);
extinc2014_ml_log = log10(extinc2014_ml_res);
extinc2018_ml_log = log10(extinc2018_ml_res);
extinc2019_ml_log = log10(extinc2019_ml_res);
extinc2020_ml_log = log10(extinc2020_ml_res);
extinc2021_ml_log = log10(extinc2021_ml_res);

extinc2014_hl_log = real(extinc2014_hl_log);
extinc2018_hl_log = real(extinc2018_hl_log);
extinc2019_hl_log = real(extinc2019_hl_log);
extinc2020_hl_log = real(extinc2020_hl_log);
extinc2021_hl_log = real(extinc2021_hl_log);
extinc_5yr_hl_log = [extinc2014_hl_log extinc2018_hl_log extinc2019_hl_log extinc2020_hl_log extinc2021_hl_log];

extinc2014_ml_log = real(extinc2014_ml_log);
extinc2018_ml_log = real(extinc2018_ml_log);
extinc2019_ml_log = real(extinc2019_ml_log);
extinc2020_ml_log = real(extinc2020_ml_log);
extinc2021_ml_log = real(extinc2021_ml_log);
extinc_5yr_ml_log = [extinc2014_ml_log extinc2018_ml_log extinc2019_ml_log extinc2020_ml_log extinc2021_ml_log];

[c2014_extinc_hl f2014_extinc_hl]   = hist(extinc2014_hl_log,-10:0.25:5);
[c2018_extinc_hl f2018_extinc_hl]   = hist(extinc2018_hl_log,-10:0.25:5);
[c2019_extinc_hl f2019_extinc_hl]   = hist(extinc2019_hl_log,-10:0.25:5);
[c2020_extinc_hl f2020_extinc_hl]   = hist(extinc2020_hl_log,-10:0.25:5);
[c2021_extinc_hl f2021_extinc_hl]   = hist(extinc2021_hl_log,-10:0.25:5);
[c2014_extinc_ml f2014_extinc_ml]   = hist(extinc2014_ml_log,-10:0.25:5);
[c2018_extinc_ml f2018_extinc_ml]   = hist(extinc2018_ml_log,-10:0.25:5);
[c2019_extinc_ml f2019_extinc_ml]   = hist(extinc2019_ml_log,-10:0.25:5);
[c2020_extinc_ml f2020_extinc_ml]   = hist(extinc2020_ml_log,-10:0.25:5);
[c2021_extinc_ml f2021_extinc_ml]   = hist(extinc2021_ml_log,-10:0.25:5);
[c_5yr_extinc_hl f_5yr_extinc_hl]   = hist(extinc_5yr_hl_log,-10:0.25:5);
[c_5yr_extinc_ml f_5yr_extinc_ml]   = hist(extinc_5yr_ml_log,-10:0.25:5);

med2014_extinc_hl = nanmedian(extinc2014_hl_res);
med2018_extinc_hl = nanmedian(extinc2018_hl_res);
med2019_extinc_hl = nanmedian(extinc2019_hl_res);
med2020_extinc_hl = nanmedian(extinc2020_hl_res);
med2021_extinc_hl = nanmedian(extinc2021_hl_res);
med2014_extinc_ml = nanmedian(extinc2014_ml_res);
med2018_extinc_ml = nanmedian(extinc2018_ml_res);
med2019_extinc_ml = nanmedian(extinc2019_ml_res);
med2020_extinc_ml = nanmedian(extinc2020_ml_res);
med2021_extinc_ml = nanmedian(extinc2021_ml_res);
med_5yr_extinc_hl = nanmedian([extinc2014_hl_res extinc2018_hl_res extinc2019_hl_res extinc2020_hl_res extinc2021_hl_res]); 
med_5yr_extinc_ml = nanmedian([extinc2014_ml_res extinc2018_ml_res extinc2019_ml_res extinc2020_ml_res extinc2021_ml_res]); 
 
%% to clear variables
clear extinc2014_hl     extinc2018_hl     extinc2019_hl     extinc2020_hl     extinc2021_hl;
clear extinc2014_ml     extinc2018_ml     extinc2019_ml     extinc2020_ml     extinc2021_ml;
clear extinc2014_hl_res extinc2018_hl_res extinc2019_hl_res extinc2020_hl_res extinc2021_hl_res ;
clear extinc2014_ml_res extinc2018_ml_res extinc2019_ml_res extinc2020_ml_res extinc2021_ml_res ;
%% to plot
fz = 12;
%%
f11 = figure(11)
set(f11,'units','inch','position',[.3,.7,6,6])
plot((10:20),(10:20),'k','LineWidth',2);
hold on
plot((10:20),(10:20),'r','LineWidth',2);
bplot(extinc2014_ml_log',-1 - 0.3,'color','black');
bplot(extinc2018_ml_log',1 - 0.3,'color','black');
bplot(extinc2019_ml_log',3- 0.3,'color','black');
bplot(extinc2020_ml_log',5- 0.3,'color','black');
bplot(extinc2021_ml_log',7- 0.3,'color','black');
bplot(extinc_5yr_ml_log',9- 0.3,'color','black');

bplot(extinc2014_hl_log',-1 + 0.3,'color','red');
bplot(extinc2018_hl_log',1 + 0.3,'color','red');
bplot(extinc2019_hl_log',3 + 0.3,'color','red');
bplot(extinc2020_hl_log',5 + 0.3,'color','red');
bplot(extinc2021_hl_log',7 + 0.3,'color','red');
bplot(extinc_5yr_hl_log',9 + 0.3,'color','red');
set(gca,'xlim',[-2 10],'xtick',[-1:2:9],'FontSize',fz);
set(gca,'xticklabel',{'2014';'2018';'2019';'2020';'2021';'5 yrs'},'FontSize',fz)
set(gca,'ylim',[-2.5 0.5],'ytick',[-2:1:1],'FontSize',fz)
set(gca,'yticklabel',{'0.01';'0.10';'1.00';'10.0'},'FontSize',fz)
set(gca,'yminortick','on');
set(gca,'tickdir','out');
legend('ML','HL')
ylabel('Extinction coeff. [km^{-1}]','Fontweight','bold','FontSize',fz);
if fileext(3) == 'D'
    text(0.3-2,0.40,[mm_str ', ' num2str(hmin) '-' num2str(hmax) 'km'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
    text(0.3-2,0.25,['Day time'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
elseif fileext(2) == 'D' & fileext(3) == 'N'
    text(0.3-2,0.40,[mm_str ', ' num2str(hmin) '-' num2str(hmax) 'km'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
    text(0.3-2,0.25,['Day + Night'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
else
    text(0.3-2,0.40,[mm_str ', ' num2str(hmin) '-' num2str(hmax) 'km'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
    text(0.3-2,0.25,['Night time'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
end
hold off

print('-dpng','-painters',['boxplot_extinc_CirrusHLvsML_' mm_str '_H' num2str(hmin) '-' num2str(hmax)  fileext(1:10) '_1p_5yr_sum.png']);
print(f11, ['boxplot_extinc_CirrusHLvsML_' mm_str '_H' num2str(hmin) '-' num2str(hmax) fileext(1:10) '_1p_5yr_sum'], '-dpdf');
%%