%% this routine is to display the distribution of depolarization ratio in different seasons of different years
%% for the case of winter, Jan.+Feb. 2014; Jan. + Feb.2018; Dec.2018 + Jan. + Feb.2019; Dec.2019 + Jan. + Feb.2020; Dec.2020 + Jan. + Feb.2021;  
%% tested under the MATLAB 2010B
clear all; clc; format long; close all
directoryname = pwd;  %% the current folder, where the MATLAB data are stored
fileext    = '_DN_Europe.mat';
% fileext    = '_ZN_Europe.mat'
%% to load the data of FIRST month of season
mm = '03';          % to change the number (03, 06, 09, 12) for different season 
mm_str = 'MAM';     % to change the season (MAM, JJA, SON, DJF)
drtar = 'dp_ratio'; % drtar - depol of target
%% to load data of year 2014
yyyy = '2014';
    filename = ['DPOL_extinc_' yyyy '-' mm fileext];
        load([directoryname '\' filename]);
    dpr2014  = DPOL.dp_ratio;
    temp2014 = DPOL.temperature;
    lat2014  = [DPOL.latitude];
    lon2014  = [DPOL.longitude];
%% to load data of year 2018
yyyy = '2018';
if str2num(mm) > 10
    dpr2018  = [];
    temp2018 = [];
    lat2018  = [];
    lon2018  = [];
else
    filename = ['DPOL_extinc_' yyyy '-' mm fileext];
        load([directoryname '\' filename]);
    dpr2018  = DPOL.dp_ratio;
    temp2018 = DPOL.temperature;
    lat2018  = [DPOL.latitude];
    lon2018  = [DPOL.longitude];
end
%% to load data of year 2019
yyyy = '2019';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2019  = DPOL.dp_ratio;
temp2019 = DPOL.temperature;
lat2019  = [DPOL.latitude];
lon2019  = [DPOL.longitude];

%% to load data of year 2020
yyyy = '2020';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2020  = DPOL.dp_ratio;
temp2020 = DPOL.temperature;
lat2020  = [DPOL.latitude];
lon2020  = [DPOL.longitude];
%% to load data of year 2020
yyyy = '2021';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2021  = DPOL.dp_ratio;
temp2021 = DPOL.temperature;
lat2021  = [DPOL.latitude];
lon2021  = [DPOL.longitude];

%% to load the data of SECOND month of season
m2 = str2num(mm) + 1;
mm2 = num2str(mod(m2,12),'%02d');
%% to load data of year 2014
yyyy = '2014';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);    
dpr2014  = [dpr2014; DPOL.dp_ratio];
temp2014 = [temp2014; DPOL.temperature];
lat2014  = [lat2014; DPOL.latitude];
lon2014  = [lon2014; DPOL.longitude];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);    
dpr2018  = [dpr2018; DPOL.dp_ratio];
temp2018 = [temp2018; DPOL.temperature];
lat2018  = [lat2018; DPOL.latitude];
lon2018  = [lon2018; DPOL.longitude];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2019  = [dpr2019; DPOL.dp_ratio];
temp2019 = [temp2019; DPOL.temperature];
lat2019  = [lat2019; DPOL.latitude];
lon2019  = [lon2019; DPOL.longitude];
%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2020  = [dpr2020; DPOL.dp_ratio];
temp2020 = [temp2020; DPOL.temperature];
lat2020  = [lat2020; DPOL.latitude];
lon2020  = [lon2020; DPOL.longitude];
%% to load data of year 2021
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2021  = [dpr2021; DPOL.dp_ratio];
temp2021 = [temp2021; DPOL.temperature];
lat2021  = [lat2021; DPOL.latitude];
lon2021  = [lon2021; DPOL.longitude];

%% to load the data of THIRD month of season
m3 = str2num(mm) + 2;
mm3 = num2str(mod(m3,12),'%02d');
%% to load data of year 2014
yyyy = '2014';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);    
dpr2014  = [dpr2014; DPOL.dp_ratio];
temp2014 = [temp2014; DPOL.temperature];
lat2014  = [lat2014; DPOL.latitude];
lon2014  = [lon2014; DPOL.longitude];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);    
dpr2018  = [dpr2018; DPOL.dp_ratio];
temp2018 = [temp2018; DPOL.temperature];
lat2018  = [lat2018; DPOL.latitude];
lon2018  = [lon2018; DPOL.longitude];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2019  = [dpr2019; DPOL.dp_ratio];
temp2019 = [temp2019; DPOL.temperature];
lat2019  = [lat2019; DPOL.latitude];
lon2019  = [lon2019; DPOL.longitude];
%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2020  = [dpr2020; DPOL.dp_ratio];
temp2020 = [temp2020; DPOL.temperature];
lat2020  = [lat2020; DPOL.latitude];
lon2020  = [lon2020; DPOL.longitude];
%% to load data of year 2021
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2021  = [dpr2021; DPOL.dp_ratio];
temp2021 = [temp2021; DPOL.temperature];
lat2021  = [lat2021; DPOL.latitude];
lon2021  = [lon2021; DPOL.longitude];
%% height
height = DPOL.height;
%% to remove the points with cidepol < 0.1 and cidepol > 0.8
dprmin = 0.1;
dprmax = 0.8;
for jh = 1:545    
    jnan = find(dpr2014(:,jh) < dprmin | dpr2014(:,jh) > dprmax);
    dpr2014(jnan,jh) = NaN;
    jnan = find(dpr2018(:,jh) < dprmin | dpr2018(:,jh) > dprmax);
    dpr2018(jnan,jh) = NaN;
    jnan = find(dpr2019(:,jh) < dprmin | dpr2019(:,jh) > dprmax);
    dpr2019(jnan,jh) = NaN;    
    jnan = find(dpr2020(:,jh) < dprmin | dpr2020(:,jh) > dprmax);
    dpr2020(jnan,jh) = NaN;
    jnan = find(dpr2021(:,jh) < dprmin | dpr2021(:,jh) > dprmax);
    dpr2021(jnan,jh) = NaN;
end
% dpr2018_org = dpr2018;
% dpr2019_org = dpr2019;
% dpr2020_org = dpr2020;
% dpr2021_org = dpr2021;
%% to remove data not within the altitudes of 6-13 km
hmin = 6;
hmax = 12;
jhc = find(height > hmin & height < hmax);
jmin = jhc(1) - 1; %% 183 - 4.99;      216 - 5.98
jmax = jhc(end) + 1; %% 405 - 15.1 km    371 - 13.06
dpr2014(:,1:jmin) = NaN; dpr2014(:,jmax:end) = NaN;
dpr2018(:,1:jmin) = NaN; dpr2018(:,jmax:end) = NaN;
dpr2019(:,1:jmin) = NaN; dpr2019(:,jmax:end) = NaN;
dpr2020(:,1:jmin) = NaN; dpr2020(:,jmax:end) = NaN;
dpr2021(:,1:jmin) = NaN; dpr2021(:,jmax:end) = NaN;
%% to remove data with temperature higher than -38 deg
tempmax = -38;
dpr2014(temp2014 > tempmax) = NaN;
dpr2018(temp2018 > tempmax) = NaN;
dpr2019(temp2019 > tempmax) = NaN;
dpr2020(temp2020 > tempmax) = NaN;
dpr2021(temp2021 > tempmax) = NaN;
%%
lat5yr = [lat2014; lat2018; lat2019; lat2020; lat2021];
dpr5yr = [dpr2014; dpr2018; dpr2019; dpr2020; dpr2021];
%% to sort data for ML and HL separated at latitude of 60 deg
hl2014 = find(lat2014 >= 60);
ml2014 = find(lat2014 < 60);
    dpr2014_hl = dpr2014(hl2014,:);
    dpr2014_ml = dpr2014(ml2014,:);
    temp2014_hl = temp2014(hl2014,:);
    temp2014_ml = temp2014(ml2014,:);
hl2018 = find(lat2018 >= 60);
ml2018 = find(lat2018 < 60);
    dpr2018_hl = dpr2018(hl2018,:);
    dpr2018_ml = dpr2018(ml2018,:);
    temp2018_hl = temp2018(hl2018,:);
    temp2018_ml = temp2018(ml2018,:);
hl2019 = find(lat2019 >= 60);
ml2019 = find(lat2019 < 60);
    dpr2019_hl = dpr2019(hl2019,:);
    dpr2019_ml = dpr2019(ml2019,:);
    temp2019_hl = temp2019(hl2019,:);
    temp2019_ml = temp2019(ml2019,:);
hl2020 = find(lat2020 >= 60);
ml2020 = find(lat2020 < 60);
    dpr2020_hl = dpr2020(hl2020,:);
    dpr2020_ml = dpr2020(ml2020,:);
    temp2020_hl = temp2020(hl2020,:);
    temp2020_ml = temp2020(ml2020,:);
hl2021 = find(lat2021 >= 60);
ml2021 = find(lat2021 < 60);
    dpr2021_hl = dpr2021(hl2021,:);
    dpr2021_ml = dpr2021(ml2021,:);
    temp2021_hl = temp2021(hl2021,:);
    temp2021_ml = temp2021(ml2021,:);
% clear dpr2014 dpr2018 dpr2019 dpr2020 dpr2020;
clear temp2014 temp2018 temp2019 temp2020 temp2021;
clear temp2014_hl temp2018_hl temp2019_hl temp2020_hl temp2021_hl;
clear temp2014_ml temp2018_ml temp2019_ml temp2020_ml temp2021_ml;
%%
dpr2014_hl_md  = nanmedian(reshape(dpr2014_hl,1,[]));
dpr2014_ml_md  = nanmedian(reshape(dpr2014_ml,1,[]));
dpr2018_hl_md  = nanmedian(reshape(dpr2018_hl,1,[]));
dpr2018_ml_md  = nanmedian(reshape(dpr2018_ml,1,[]));
dpr2019_hl_md  = nanmedian(reshape(dpr2019_hl,1,[]));
dpr2019_ml_md  = nanmedian(reshape(dpr2019_ml,1,[]));
dpr2020_hl_md  = nanmedian(reshape(dpr2020_hl,1,[]));
dpr2020_ml_md  = nanmedian(reshape(dpr2020_ml,1,[]));
dpr2021_hl_md  = nanmedian(reshape(dpr2021_hl,1,[]));
dpr2021_ml_md  = nanmedian(reshape(dpr2021_ml,1,[]));
md_hl    = [dpr2014_hl_md dpr2018_hl_md dpr2019_hl_md dpr2020_hl_md dpr2021_hl_md];
md_ml    = [dpr2014_ml_md dpr2018_ml_md dpr2019_ml_md dpr2020_ml_md dpr2021_ml_md];

% [c2014_hl f2014_hl]   = hist(reshape(dpr2014_hl,1,[]),0:0.05:1);
% [c2014_ml f2014_ml]   = hist(reshape(dpr2014_ml,1,[]),0:0.05:1);
% [c2018_hl f2018_hl]   = hist(reshape(dpr2018_hl,1,[]),0:0.05:1);
% [c2018_ml f2018_ml]   = hist(reshape(dpr2018_ml,1,[]),0:0.05:1);
% [c2019_hl f2019_hl]   = hist(reshape(dpr2019_hl,1,[]),0:0.05:1);
% [c2019_ml f2019_ml]   = hist(reshape(dpr2019_ml,1,[]),0:0.05:1);
% [c2020_hl f2020_hl]   = hist(reshape(dpr2020_hl,1,[]),0:0.05:1);
% [c2020_ml f2020_ml]   = hist(reshape(dpr2020_ml,1,[]),0:0.05:1);
% [c2021_hl f2021_hl]   = hist(reshape(dpr2021_hl,1,[]),0:0.05:1);
% [c2021_ml f2021_ml]   = hist(reshape(dpr2021_ml,1,[]),0:0.05:1);
%%
dpr2014_medn_hl = nanmedian(dpr2014_hl);
dpr2018_medn_hl = nanmedian(dpr2018_hl);
dpr2019_medn_hl = nanmedian(dpr2019_hl);
dpr2020_medn_hl = nanmedian(dpr2020_hl);
dpr2021_medn_hl = nanmedian(dpr2021_hl);
dpr_5yr_medn_hl = nanmedian([dpr2014_hl; dpr2018_hl; dpr2019_hl; dpr2020_hl; dpr2021_hl]);
clear dpr2014_hl dpr2018_hl dpr2019_hl dpr2020_hl dpr2021_hl;

dpr2014_medn_ml = nanmedian(dpr2014_ml);
dpr2018_medn_ml = nanmedian(dpr2018_ml);
dpr2019_medn_ml = nanmedian(dpr2019_ml);
dpr2020_medn_ml = nanmedian(dpr2020_ml);
dpr2021_medn_ml = nanmedian(dpr2021_ml);
dpr_5yr_medn_ml = nanmedian([dpr2014_ml; dpr2018_ml; dpr2019_ml; dpr2020_ml; dpr2021_ml]);
clear dpr2014_ml dpr2018_ml dpr2019_ml dpr2020_ml dpr2021_ml;
%%
latdim = 35:0.1:80;
dpr2014_lat_prc = NaN(3,length(latdim));
dpr2018_lat_prc = NaN(3,length(latdim));
dpr2019_lat_prc = NaN(3,length(latdim));
dpr2020_lat_prc = NaN(3,length(latdim));
dpr2021_lat_prc = NaN(3,length(latdim));
dpr5yr_lat_prc = NaN(3,length(latdim));
% 
% for jl = 1:length(latdim) - 1
%     idx_lat = find(lat2014 >= latdim(jl) & lat2014 < latdim(jl+1));
%     dpr2014_lat_prc(2,jl) = nanmedian(reshape(dpr2014(idx_lat,:),1,[]));
%     
%     idx_lat = find(lat2018 >= latdim(jl) & lat2018 < latdim(jl+1));
%     dpr2018_lat_prc(2,jl) = nanmedian(reshape(dpr2018(idx_lat,:),1,[]));
%     
%     idx_lat = find(lat2019 >= latdim(jl) & lat2019 < latdim(jl+1));
%     dpr2019_lat_prc(2,jl) = nanmedian(reshape(dpr2019(idx_lat,:),1,[]));
%     
%     idx_lat = find(lat2020 >= latdim(jl) & lat2020 < latdim(jl+1));
%     dpr2020_lat_prc(2,jl) = nanmedian(reshape(dpr2020(idx_lat,:),1,[]));
%     
%     idx_lat = find(lat2021 >= latdim(jl) & lat2021 < latdim(jl+1));
%     dpr2021_lat_prc(2,jl) = nanmedian(reshape(dpr2021(idx_lat,:),1,[]));
%     
%     idx_lat = find(lat5yr >= latdim(jl) & lat5yr < latdim(jl+1));
%     dpr5yr_lat_prc(2,jl) = nanmedian(reshape(dpr5yr(idx_lat,:),1,[]));
% end
prctl75 =  @(v) interp1(linspace(1/numel(v),1,numel(v)), sort(v), 0.75, 'nearest');
prctl50 =  @(v) interp1(linspace(1/numel(v),1,numel(v)), sort(v), 0.50, 'nearest');
prctl25 =  @(v) interp1(linspace(1/numel(v),1,numel(v)), sort(v), 0.25, 'nearest');
for jl = 1:length(latdim) - 1
    idx_lat = find(lat2014 >= latdim(jl) & lat2014 < latdim(jl+1));
    var2014 =  reshape(dpr2014(idx_lat,:),1,[]);
    var2014(isnan(var2014)) = [];
    dpr2014_lat_prc(1,jl) = prctl25(var2014);
    dpr2014_lat_prc(2,jl) = prctl50(var2014);
    dpr2014_lat_prc(3,jl) = prctl75(var2014);
    
    idx_lat = find(lat2018 >= latdim(jl) & lat2018 < latdim(jl+1));
    var2018 =  reshape(dpr2018(idx_lat,:),1,[]);
    var2018(isnan(var2018)) = [];
    dpr2018_lat_prc(1,jl) = prctl25(var2018);
    dpr2018_lat_prc(2,jl) = prctl50(var2018);
    dpr2018_lat_prc(3,jl) = prctl75(var2018);
    
    idx_lat = find(lat2019 >= latdim(jl) & lat2019 < latdim(jl+1));
    var2019 =  reshape(dpr2019(idx_lat,:),1,[]);
    var2019(isnan(var2019)) = [];
    dpr2019_lat_prc(1,jl) = prctl25(var2019);
    dpr2019_lat_prc(2,jl) = prctl50(var2019);
    dpr2019_lat_prc(3,jl) = prctl75(var2019);
    
    idx_lat = find(lat2020 >= latdim(jl) & lat2020 < latdim(jl+1));
    var2020 =  reshape(dpr2020(idx_lat,:),1,[]);
    var2020(isnan(var2020)) = [];
    dpr2020_lat_prc(1,jl) = prctl25(var2020);
    dpr2020_lat_prc(2,jl) = prctl50(var2020);
    dpr2020_lat_prc(3,jl) = prctl75(var2020);
    
    idx_lat = find(lat2021 >= latdim(jl) & lat2021 < latdim(jl+1));
    var2021 =  reshape(dpr2021(idx_lat,:),1,[]);
    var2021(isnan(var2021)) = [];
    dpr2021_lat_prc(1,jl) = prctl25(var2021);
    dpr2021_lat_prc(2,jl) = prctl50(var2021);
    dpr2021_lat_prc(3,jl) = prctl75(var2021);
    
    idx_lat = find(lat5yr >= latdim(jl) & lat5yr < latdim(jl+1));
    var5yr =  reshape(dpr5yr(idx_lat,:),1,[]);
    var5yr(isnan(var5yr)) = [];
    dpr5yr_lat_prc(1,jl) = prctl25(var5yr);
    dpr5yr_lat_prc(2,jl) = prctl50(var5yr);
    dpr5yr_lat_prc(3,jl) = prctl75(var5yr);
end
%% to plot
fz = 11;

%% to calculate the PLDR in different latitudes
lat_stp = 35:5:80; %% steps of latitude
istp = length(lat_stp) - 1;
dpr2014_prc25 = NaN(1,istp);
dpr2014_prc50 = NaN(1,istp);
dpr2014_prc75 = NaN(1,istp);
dpr2018_prc25 = NaN(1,istp);
dpr2018_prc50 = NaN(1,istp);
dpr2018_prc75 = NaN(1,istp);
dpr2019_prc25 = NaN(1,istp);
dpr2019_prc50 = NaN(1,istp);
dpr2019_prc75 = NaN(1,istp);
dpr2020_prc25 = NaN(1,istp);
dpr2020_prc50 = NaN(1,istp);
dpr2020_prc75 = NaN(1,istp);
dpr2021_prc25 = NaN(1,istp);
dpr2021_prc50 = NaN(1,istp);
dpr2021_prc75 = NaN(1,istp);
dpr5yr_prc25 = NaN(1,istp);
dpr5yr_prc50 = NaN(1,istp);
dpr5yr_prc75 = NaN(1,istp);
f10 = figure(10)
set(f10,'units','inch','position',[.3,2.0,9,6])
subplot(2,3,1)
for jl = 1:istp
    idx_lat2014 = find(lat2014 >= lat_stp(jl) & lat2014 < lat_stp(jl + 1));
    hold on
    bplot(reshape(dpr2014(idx_lat2014,:),1,[]),jl,'width',0.7); 
    dprres_lat = reshape(dpr2014(idx_lat2014,:),1,[]);    
    dprres_lat(isnan(dprres_lat)) = [];
    dpr2014_prc25(jl) = prctl25(dprres_lat);
    dpr2014_prc50(jl) = prctl50(dprres_lat);
    dpr2014_prc75(jl) = prctl75(dprres_lat);
end
set(gca,'ylim',[0.1 0.8],'ytick',[0:0.1:0.8],'Fontsize',fz);
set(gca,'xlim',[0 10],'xtick',[0.5:1:10],'Fontsize',fz);
set(gca,'xticklabel',{'35';'';'45';'';'55';'';'65';'';'75';'';'85';});
set(gca,'tickdir','out');
ylabel(['Depolarization ratio (PLDR)'],'fontweight','bold','FontSize',fz);
if fileext(3) == 'D'
    text(0.2,0.76,['ZD ' num2str(hmin) '-' num2str(hmax) 'km '],'backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
elseif length(drtar) < 10 &  fileext(2) == 'D' & fileext(3) == 'N'
    text(0.2,0.76,['DN, ' num2str(hmin) '-' num2str(hmax) 'km '],'fontweight','bold','backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
else
    text(0.2,0.76,['ZN, ' num2str(hmin) '-' num2str(hmax) 'km '],'fontweight','bold','backgroundcolor',[0.8 0.8 0.8],'FontSize',fz);
end
text(5.6,0.76, [ mm_str(1:3) ' 2014' ],'fontweight','bold','FontSize',fz);
hold off
subplot(2,3,2)
for jl = 1:istp
    idx_lat2018 = find(lat2018 >= lat_stp(jl) & lat2018 < lat_stp(jl + 1));
    hold on
    bplot(reshape(dpr2018(idx_lat2018,:),1,[]),jl,'width',0.7);      
    dprres_lat = reshape(dpr2018(idx_lat2018,:),1,[]);    
    dprres_lat(isnan(dprres_lat)) = [];
    dpr2018_prc25(jl) = prctl25(dprres_lat);
    dpr2018_prc50(jl) = prctl50(dprres_lat);
    dpr2018_prc75(jl) = prctl75(dprres_lat);
end
set(gca,'ylim',[0.1 0.8],'ytick',[0:0.1:0.8],'Fontsize',fz);
set(gca,'xlim',[0 10],'xtick',[0.5:1:10],'Fontsize',fz);
set(gca,'xticklabel',{'35';'';'45';'';'55';'';'65';'';'75';'';'85';});
set(gca,'tickdir','out');
% ylabel('Depolarization ratio, T < -38 \circC','FontSize',fz);
text(5.6,0.76, [ mm_str(1:3) ' 2018' ],'fontweight','bold','FontSize',fz);
hold off
subplot(2,3,3)
for jl = 1:istp
    idx_lat2019 = find(lat2019 >= lat_stp(jl) & lat2019 < lat_stp(jl + 1));
    hold on
    bplot(reshape(dpr2019(idx_lat2019,:),1,[]),jl,'width',0.7);     
    dprres_lat = reshape(dpr2019(idx_lat2019,:),1,[]);    
    dprres_lat(isnan(dprres_lat)) = [];
    dpr2019_prc25(jl) = prctl25(dprres_lat);
    dpr2019_prc50(jl) = prctl50(dprres_lat);
    dpr2019_prc75(jl) = prctl75(dprres_lat);   
end
set(gca,'ylim',[0.1 0.8],'ytick',[0:0.1:0.8],'Fontsize',fz);
set(gca,'xlim',[0 10],'xtick',[0.5:1:10],'Fontsize',fz);
set(gca,'xticklabel',{'35';'';'45';'';'55';'';'65';'';'75';'';'85';});
set(gca,'tickdir','out');

text(5.6,0.76, [ mm_str(1:3) ' 2019' ],'fontweight','bold','FontSize',fz);
hold off
subplot(2,3,4)
for jl = 1:istp
    idx_lat2020 = find(lat2020 >= lat_stp(jl) & lat2020 < lat_stp(jl + 1));
    hold on
    bplot(reshape(dpr2020(idx_lat2020,:),1,[]),jl,'width',0.7);      
    dprres_lat = reshape(dpr2020(idx_lat2020,:),1,[]);    
    dprres_lat(isnan(dprres_lat)) = [];
    dpr2020_prc25(jl) = prctl25(dprres_lat);
    dpr2020_prc50(jl) = prctl50(dprres_lat);
    dpr2020_prc75(jl) = prctl75(dprres_lat);    
end
set(gca,'ylim',[0.1 0.8],'ytick',[0:0.1:0.8],'Fontsize',fz);
set(gca,'xlim',[0 10],'xtick',[0.5:1:10],'Fontsize',fz);
set(gca,'xticklabel',{'35';'';'45';'';'55';'';'65';'';'75';'';'85';});
set(gca,'tickdir','out');
xlabel('Latitude [\circ]','fontweight','bold','FontSize',fz);
ylabel(['Depolarization ratio, (PLDR)'],'fontweight','bold','FontSize',fz);

text(5.6,0.76, [ mm_str(1:3) ' 2020' ],'fontweight','bold','FontSize',fz);
hold off
subplot(2,3,5)
for jl = 1:istp
    idx_lat2021 = find(lat2021 >= lat_stp(jl) & lat2021 < lat_stp(jl + 1));
    hold on
    bplot(reshape(dpr2021(idx_lat2021,:),1,[]),jl,'width',0.7);     
    dprres_lat = reshape(dpr2021(idx_lat2021,:),1,[]);    
    dprres_lat(isnan(dprres_lat)) = [];
    dpr2021_prc25(jl) = prctl25(dprres_lat);
    dpr2021_prc50(jl) = prctl50(dprres_lat);
    dpr2021_prc75(jl) = prctl75(dprres_lat);     
end
set(gca,'ylim',[0.1 0.8],'ytick',[0:0.1:0.8],'Fontsize',fz);
set(gca,'xlim',[0 10],'xtick',[0.5:1:10],'Fontsize',fz);
set(gca,'xticklabel',{'35';'';'45';'';'55';'';'65';'';'75';'';'85';});
set(gca,'tickdir','out');
xlabel('Latitude [\circ]','fontweight','bold','FontSize',fz);

text(5.6,0.76, [ mm_str(1:3) ' 2021' ],'fontweight','bold','FontSize',fz);
hold off
subplot(2,3,6)
for jl = 1:istp
    idx_lat5yr = find(lat5yr >= lat_stp(jl) & lat5yr < lat_stp(jl + 1));
    hold on
    bplot(reshape(dpr5yr(idx_lat5yr,:),1,[]),jl,'width',0.7);        
    dprres_lat = reshape(dpr5yr(idx_lat5yr,:),1,[]);    
    dprres_lat(isnan(dprres_lat)) = [];
    dpr5yr_prc25(jl) = prctl25(dprres_lat);
    dpr5yr_prc50(jl) = prctl50(dprres_lat);
    dpr5yr_prc75(jl) = prctl75(dprres_lat); 
end
set(gca,'ylim',[0.1 0.8],'ytick',[0:0.1:0.8],'Fontsize',fz);
set(gca,'xlim',[0 10],'xtick',[0.5:1:10],'Fontsize',fz);
set(gca,'xticklabel',{'35';'';'45';'';'55';'';'65';'';'75';'';'85';});
set(gca,'tickdir','out');
xlabel('Latitude [\circ]','fontweight','bold','FontSize',fz);
text(5.6,0.76, [ mm_str(1:3) ' 5 yrs' ],'fontweight','bold','FontSize',fz);
hold off

print('-dpng','-painters',['boxplot_Depol_vsLat_T_' num2str(abs(tempmax)) '_CirrusHL_hgt' num2str(hmin) '-' num2str(hmax) '_' mm_str fileext(1:10) '_5yr.png']);
print(f10, ['boxplot_Depol_vsLat_T_' num2str(abs(tempmax)) '_CirrusHL_hgt' num2str(hmin) '-' num2str(hmax) '_' mm_str fileext(1:10) '_5yr'], '-dpdf')

%%
