%% this routine is to display the distribution of depolarization ratio in different years of 2014 and 2018-2021
%% tested under the MATLAB 2010B
clear all; clc; format long; close all
directoryname = pwd;  %% the current folder, where the MATLAB data are stored
%%
fileext    = '_DN_Europe.mat'
% fileext    = '_ZD_Europe.mat';
%% to load the data of FIRST month of season
mm = '03';          % to change the number (03, 06, 09, 12) for different season 
mm_str = 'MAM';     % to change the season (MAM, JJA, SON, DJF)
drtar = 'dp_ratio'; % drtar - depol of target
%% to load data of year 2014
yyyy = '2014';
    filename = ['DPOL_extinc_' yyyy '-' mm fileext];
        load([directoryname '\' filename]);
    dpr2014  = DPOL.dp_ratio;
    temp2014 = DPOL.temperature;
    lat2014  = [DPOL.latitude];
    lon2014  = [DPOL.longitude];
%% to load data of year 2018
yyyy = '2018';
if str2num(mm) > 10
    dpr2018  = [];
    temp2018 = [];
    lat2018  = [];
    lon2018  = [];
else
    filename = ['DPOL_extinc_' yyyy '-' mm fileext];
        load([directoryname '\' filename]);
    dpr2018  = DPOL.dp_ratio;
    temp2018 = DPOL.temperature;
    lat2018  = [DPOL.latitude];
    lon2018  = [DPOL.longitude];
end
%% to load data of year 2019
yyyy = '2019';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2019  = DPOL.dp_ratio;
temp2019 = DPOL.temperature;
lat2019  = [DPOL.latitude];
lon2019  = [DPOL.longitude];

%% to load data of year 2020
yyyy = '2020';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2020  = DPOL.dp_ratio;
temp2020 = DPOL.temperature;
lat2020  = [DPOL.latitude];
lon2020  = [DPOL.longitude];
%% to load data of year 2020
yyyy = '2021';
if str2num(mm) > 10;    
    yyyy = num2str(str2num(yyyy) - 1);
end
filename = ['DPOL_extinc_' yyyy '-' mm fileext];
    load([directoryname '\' filename]);
dpr2021  = DPOL.dp_ratio;
temp2021 = DPOL.temperature;
lat2021  = [DPOL.latitude];
lon2021  = [DPOL.longitude];
%% to load the data of SECOND month of season
m2 = str2num(mm) + 1;
mm2 = num2str(mod(m2,12),'%02d');
%% to load data of year 2014
yyyy = '2014';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);    
dpr2014  = [dpr2014; DPOL.dp_ratio];
temp2014 = [temp2014; DPOL.temperature];
lat2014  = [lat2014; DPOL.latitude];
lon2014  = [lon2014; DPOL.longitude];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);    
dpr2018  = [dpr2018; DPOL.dp_ratio];
temp2018 = [temp2018; DPOL.temperature];
lat2018  = [lat2018; DPOL.latitude];
lon2018  = [lon2018; DPOL.longitude];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2019  = [dpr2019; DPOL.dp_ratio];
temp2019 = [temp2019; DPOL.temperature];
lat2019  = [lat2019; DPOL.latitude];
lon2019  = [lon2019; DPOL.longitude];
%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2020  = [dpr2020; DPOL.dp_ratio];
temp2020 = [temp2020; DPOL.temperature];
lat2020  = [lat2020; DPOL.latitude];
lon2020  = [lon2020; DPOL.longitude];
%% to load data of year 2021
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm2 fileext];
    load([directoryname '\' filename]);
dpr2021  = [dpr2021; DPOL.dp_ratio];
temp2021 = [temp2021; DPOL.temperature];
lat2021  = [lat2021; DPOL.latitude];
lon2021  = [lon2021; DPOL.longitude];

%% to load the data of THIRD month of season
m3 = str2num(mm) + 2;
mm3 = num2str(mod(m3,12),'%02d');
%% to load data of year 2014
yyyy = '2014';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);    
dpr2014  = [dpr2014; DPOL.dp_ratio];
temp2014 = [temp2014; DPOL.temperature];
lat2014  = [lat2014; DPOL.latitude];
lon2014  = [lon2014; DPOL.longitude];
%% to load data of year 2018
yyyy = '2018';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);    
dpr2018  = [dpr2018; DPOL.dp_ratio];
temp2018 = [temp2018; DPOL.temperature];
lat2018  = [lat2018; DPOL.latitude];
lon2018  = [lon2018; DPOL.longitude];
%% to load data of year 2019
yyyy = '2019';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2019  = [dpr2019; DPOL.dp_ratio];
temp2019 = [temp2019; DPOL.temperature];
lat2019  = [lat2019; DPOL.latitude];
lon2019  = [lon2019; DPOL.longitude];
%% to load data of year 2020
yyyy = '2020';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2020  = [dpr2020; DPOL.dp_ratio];
temp2020 = [temp2020; DPOL.temperature];
lat2020  = [lat2020; DPOL.latitude];
lon2020  = [lon2020; DPOL.longitude];
%% to load data of year 2021
yyyy = '2021';
filename = ['DPOL_extinc_' yyyy '-' mm3 fileext];
    load([directoryname '\' filename]);
dpr2021  = [dpr2021; DPOL.dp_ratio];
temp2021 = [temp2021; DPOL.temperature];
lat2021  = [lat2021; DPOL.latitude];
lon2021  = [lon2021; DPOL.longitude];
%% height
height = DPOL.height;
%% to remove the points with cidepol < 0.1 and cidepol > 0.8
dprmin = 0.1;
dprmax = 0.8;
for jh = 1:545    
    jnan = find(dpr2014(:,jh) < dprmin | dpr2014(:,jh) > dprmax);
    dpr2014(jnan,jh) = NaN;  
    jnan = find(dpr2018(:,jh) < dprmin | dpr2018(:,jh) > dprmax);
    dpr2018(jnan,jh) = NaN;  
    jnan = find(dpr2019(:,jh) < dprmin | dpr2019(:,jh) > dprmax);
    dpr2019(jnan,jh) = NaN;    
    jnan = find(dpr2020(:,jh) < dprmin | dpr2020(:,jh) > dprmax);
    dpr2020(jnan,jh) = NaN;
    jnan = find(dpr2021(:,jh) < dprmin | dpr2021(:,jh) > dprmax);
    dpr2021(jnan,jh) = NaN;
end
%% to remove data with temperature higher than -38 deg
dpr2014(temp2014 > -38) = NaN;
dpr2018(temp2018 > -38) = NaN;
dpr2019(temp2019 > -38) = NaN;
dpr2020(temp2020 > -38) = NaN;
dpr2021(temp2021 > -38) = NaN;
%% to filter data within aviation height of 6-13 km
hmin = 6;
hmax = 12;
jhc = find(height > hmin & height < hmax);
jmin = jhc(1) - 1; %% 183 - 4.99;      216 - 5.98
jmax = jhc(end) + 1; %% 405 - 15.1 km    371 - 13.06
dpr2014(:,1:jmin) = NaN; dpr2014(:,jmax:end) = NaN;
dpr2018(:,1:jmin) = NaN; dpr2018(:,jmax:end) = NaN;
dpr2019(:,1:jmin) = NaN; dpr2019(:,jmax:end) = NaN;
dpr2020(:,1:jmin) = NaN; dpr2020(:,jmax:end) = NaN;
dpr2021(:,1:jmin) = NaN; dpr2021(:,jmax:end) = NaN;
%% to sort data for ML and HL separated at latitude of 60 deg
hl2014 = find(lat2014 >= 60);
ml2014 = find(lat2014 < 60);
    dpr2014_hl = dpr2014(hl2014,:);
    dpr2014_ml = dpr2014(ml2014,:);
    temp2014_hl = temp2014(hl2014,:);
    temp2014_ml = temp2014(ml2014,:);
hl2018 = find(lat2018 >= 60);
ml2018 = find(lat2018 < 60);
    dpr2018_hl = dpr2018(hl2018,:);
    dpr2018_ml = dpr2018(ml2018,:);
    temp2018_hl = temp2018(hl2018,:);
    temp2018_ml = temp2018(ml2018,:);
hl2019 = find(lat2019 >= 60);
ml2019 = find(lat2019 < 60);
    dpr2019_hl = dpr2019(hl2019,:);
    dpr2019_ml = dpr2019(ml2019,:);
    temp2019_hl = temp2019(hl2019,:);
    temp2019_ml = temp2019(ml2019,:);
hl2020 = find(lat2020 >= 60);
ml2020 = find(lat2020 < 60);
    dpr2020_hl = dpr2020(hl2020,:);
    dpr2020_ml = dpr2020(ml2020,:);
    temp2020_hl = temp2020(hl2020,:);
    temp2020_ml = temp2020(ml2020,:);
hl2021 = find(lat2021 >= 60);
ml2021 = find(lat2021 < 60);
    dpr2021_hl = dpr2021(hl2021,:);
    dpr2021_ml = dpr2021(ml2021,:);
    temp2021_hl = temp2021(hl2021,:);
    temp2021_ml = temp2021(ml2021,:);
%% to calculate the mean and standard deviation    
dpr2014_ml_ave = nanmean(dpr2014_ml);
dpr2014_ml_std = nanstd(dpr2014_ml);
dpr2018_ml_ave = nanmean(dpr2018_ml);
dpr2018_ml_std = nanstd(dpr2018_ml);
dpr2019_ml_ave = nanmean(dpr2019_ml);
dpr2019_ml_std = nanstd(dpr2019_ml);
dpr2020_ml_ave = nanmean(dpr2020_ml);
dpr2020_ml_std = nanstd(dpr2020_ml);
dpr2021_ml_ave = nanmean(dpr2021_ml);
dpr2021_ml_std = nanstd(dpr2021_ml);  

dpr2014_hl_ave = nanmean(dpr2014_hl);
dpr2014_hl_std = nanstd(dpr2014_hl);
dpr2018_hl_ave = nanmean(dpr2018_hl);
dpr2018_hl_std = nanstd(dpr2018_hl);
dpr2019_hl_ave = nanmean(dpr2019_hl);
dpr2019_hl_std = nanstd(dpr2019_hl);
dpr2020_hl_ave = nanmean(dpr2020_hl);
dpr2020_hl_std = nanstd(dpr2020_hl);
dpr2021_hl_ave = nanmean(dpr2021_hl);
dpr2021_hl_std = nanstd(dpr2021_hl);
%% percentile
prc_rng = [25 50 75];
dpr2014_ml_prc = prctile(dpr2014_ml,prc_rng);
dpr2018_ml_prc = prctile(dpr2018_ml,prc_rng);
dpr2019_ml_prc = prctile(dpr2019_ml,prc_rng);
dpr2020_ml_prc = prctile(dpr2020_ml,prc_rng);
dpr2021_ml_prc = prctile(dpr2021_ml,prc_rng);

dpr2014_hl_prc = prctile(dpr2014_hl,prc_rng);
dpr2018_hl_prc = prctile(dpr2018_hl,prc_rng);
dpr2019_hl_prc = prctile(dpr2019_hl,prc_rng);
dpr2020_hl_prc = prctile(dpr2020_hl,prc_rng);
dpr2021_hl_prc = prctile(dpr2021_hl,prc_rng);

nump_ci2014_ml = NaN(size(height));
nump_ci2018_ml = NaN(size(height));
nump_ci2019_ml = NaN(size(height));
nump_ci2020_ml = NaN(size(height));
nump_ci2021_ml = NaN(size(height));

nump_ci2014_hl = NaN(size(height));
nump_ci2018_hl = NaN(size(height));
nump_ci2019_hl = NaN(size(height));
nump_ci2020_hl = NaN(size(height));
nump_ci2021_hl = NaN(size(height));
for jh = 1:545
    j2014 = find(~isnan(dpr2014_ml(:,jh)));
    if isempty(j2014)
        continue
    else
        nump_ci2014_ml(jh) = length(j2014);
    end
    j2018 = find(~isnan(dpr2018_ml(:,jh)));
    if isempty(j2018)
        continue
    else
        nump_ci2018_ml(jh) = length(j2018);
    end
    j2019 = find(~isnan(dpr2019_ml(:,jh)));
    if isempty(j2019)
        continue
    else
        nump_ci2019_ml(jh) = length(j2019);
    end
    j2020 = find(~isnan(dpr2020_ml(:,jh)));
    if isempty(j2020)
        continue
    else
        nump_ci2020_ml(jh) = length(j2020);
    end
    j2021 = find(~isnan(dpr2021_ml(:,jh)));
    if isempty(j2021)
        continue
    else
        nump_ci2021_ml(jh) = length(j2021);
    end
end
for jh = 1:545
    j2014 = find(~isnan(dpr2014_hl(:,jh)));
    if isempty(j2014)
        continue
    else
        nump_ci2014_hl(jh) = length(j2014);
    end
    j2018 = find(~isnan(dpr2018_hl(:,jh)));
    if isempty(j2018)
        continue
    else
        nump_ci2018_hl(jh) = length(j2018);
    end
    j2019 = find(~isnan(dpr2019_hl(:,jh)));
    if isempty(j2019)
        continue
    else
        nump_ci2019_hl(jh) = length(j2019);
    end
    j2020 = find(~isnan(dpr2020_hl(:,jh)));
    if isempty(j2020)
        continue
    else
        nump_ci2020_hl(jh) = length(j2020);
    end
    j2021 = find(~isnan(dpr2021_hl(:,jh)));
    if isempty(j2021)
        continue
    else
        nump_ci2021_hl(jh) = length(j2021);
    end
end

perc2014_ml = nump_ci2014_ml./size(dpr2014_ml,1)*100;
perc2018_ml = nump_ci2018_ml./size(dpr2018_ml,1)*100;
perc2019_ml = nump_ci2019_ml./size(dpr2019_ml,1)*100;
perc2020_ml = nump_ci2020_ml./size(dpr2020_ml,1)*100;
perc2021_ml = nump_ci2021_ml./size(dpr2021_ml,1)*100;

perc2014_hl = nump_ci2014_hl./size(dpr2014_hl,1)*100;
perc2018_hl = nump_ci2018_hl./size(dpr2018_hl,1)*100;
perc2019_hl = nump_ci2019_hl./size(dpr2019_hl,1)*100;
perc2020_hl = nump_ci2020_hl./size(dpr2020_hl,1)*100;
perc2021_hl = nump_ci2021_hl./size(dpr2021_hl,1)*100;
%% %% 
dpr2014_hl_res = reshape(dpr2014_hl,1,[]);
dpr2018_hl_res = reshape(dpr2018_hl,1,[]);
dpr2019_hl_res = reshape(dpr2019_hl,1,[]);
dpr2020_hl_res = reshape(dpr2020_hl,1,[]);
dpr2021_hl_res = reshape(dpr2021_hl,1,[]);
dpr_5yr_hl_res = [dpr2014_hl_res dpr2018_hl_res  dpr2019_hl_res dpr2020_hl_res dpr2021_hl_res];
dpr2014_ml_res = reshape(dpr2014_ml,1,[]);
dpr2018_ml_res = reshape(dpr2018_ml,1,[]);
dpr2019_ml_res = reshape(dpr2019_ml,1,[]);
dpr2020_ml_res = reshape(dpr2020_ml,1,[]);
dpr2021_ml_res = reshape(dpr2021_ml,1,[]);
dpr_5yr_ml_res = [dpr2014_ml_res dpr2018_ml_res  dpr2019_ml_res dpr2020_ml_res dpr2021_ml_res];
[c2014_hl f2014_hl]   = hist(dpr2014_hl_res,0:0.05:1);
[c2018_hl f2018_hl]   = hist(dpr2018_hl_res,0:0.05:1);
[c2019_hl f2019_hl]   = hist(dpr2019_hl_res,0:0.05:1);
[c2020_hl f2020_hl]   = hist(dpr2020_hl_res,0:0.05:1);
[c2021_hl f2021_hl]   = hist(dpr2021_hl_res,0:0.05:1);
[c2014_ml f2014_ml]   = hist(dpr2014_ml_res,0:0.05:1);
[c2018_ml f2018_ml]   = hist(dpr2018_ml_res,0:0.05:1);
[c2019_ml f2019_ml]   = hist(dpr2019_ml_res,0:0.05:1);
[c2020_ml f2020_ml]   = hist(dpr2020_ml_res,0:0.05:1);
[c2021_ml f2021_ml]   = hist(dpr2021_ml_res,0:0.05:1);
[c_5yr_hl f_5yr_hl]   = hist(dpr_5yr_hl_res,0:0.05:1);
[c_5yr_ml f_5yr_ml]   = hist(dpr_5yr_ml_res,0:0.05:1);

med2014_hl = nanmedian(dpr2014_hl_res);
med2018_hl = nanmedian(dpr2018_hl_res);
med2019_hl = nanmedian(dpr2019_hl_res);
med2020_hl = nanmedian(dpr2020_hl_res);
med2021_hl = nanmedian(dpr2021_hl_res);
med2014_ml = nanmedian(dpr2014_ml_res);
med2018_ml = nanmedian(dpr2018_ml_res);
med2019_ml = nanmedian(dpr2019_ml_res);
med2020_ml = nanmedian(dpr2020_ml_res);
med2021_ml = nanmedian(dpr2021_ml_res);
med_5yr_hl = nanmedian([dpr2014_hl_res dpr2018_hl_res  dpr2019_hl_res dpr2020_hl_res dpr2021_hl_res]); 
med_5yr_ml = nanmedian([dpr2014_ml_res dpr2018_ml_res  dpr2019_ml_res dpr2020_ml_res dpr2021_ml_res]); 
%% to plot
fz = 12;
%%
f22 = figure(22)
set(f22,'units','inch','position',[.3,.7,6,6])
plot((10:20),(10:20),'k','LineWidth',2);
hold on
plot((10:20),(10:20),'r','LineWidth',2);
bplot(dpr2014_ml_res',-1 - 0.3,'color','black');
bplot(dpr2018_ml_res',1 - 0.3,'color','black');
bplot(dpr2019_ml_res',3- 0.3,'color','black');
bplot(dpr2020_ml_res',5- 0.3,'color','black');
bplot(dpr2021_ml_res',7- 0.3,'color','black');
bplot(dpr_5yr_ml_res',9- 0.3,'color','black');

bplot(dpr2014_hl_res',-1 + 0.3,'color','red');
bplot(dpr2018_hl_res',1 + 0.3,'color','red');
bplot(dpr2019_hl_res',3 + 0.3,'color','red');
bplot(dpr2020_hl_res',5 + 0.3,'color','red');
bplot(dpr2021_hl_res',7 + 0.3,'color','red');
bplot(dpr_5yr_hl_res',9 + 0.3,'color','red');
set(gca,'xlim',[-2 10],'xtick',[-1:2:9],'FontSize',fz);
set(gca,'xticklabel',{'2014';'2018';'2019';'2020';'2021';'5 yrs'},'FontSize',fz)
set(gca,'ylim',[0.05 0.85],'FontSize',fz)
set(gca,'yminortick','on');
set(gca,'tickdir','out');
legend('ML','HL')
 ylabel('Depolarization ratio (PLDR)','FontWeight','bold','FontSize',20);
if fileext(3) == 'D'
    text(0.3-2,0.82,[mm_str ', H: ' num2str(hmin) '-' num2str(hmax) 'km'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
    text(0.3-2,0.77,['Day time'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
elseif  fileext(2) == 'Z' & fileext(3) == 'N'
    text(0.3-2,0.82,[mm_str ', H: ' num2str(hmin) '-' num2str(hmax) 'km'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
    text(0.3-2,0.77,['Night time'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
else
    text(0.3-2,0.82,[mm_str ', H: ' num2str(hmin) '-' num2str(hmax) 'km'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
    text(0.3-2,0.77,['Day + Ngt'],'backgroundcolor',[0.8 0.8 0.8],'FontSize',15);
end
hold off


print('-dpng','-painters',['boxplot_depol_CirrusHLvsML_' mm_str '_H' num2str(hmin) '-' num2str(hmax)  fileext(1:10) '_1p_5yr_sum.png']);
print(f22, ['boxplot_depol_CirrusHLvsML_' mm_str '_H' num2str(hmin) '-' num2str(hmax) fileext(1:10) '_1p_5yr_sum'], '-dpdf');

%%
